"""
URL configuration for the listings app.
"""

from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import PetCategoryViewSet, PetListingViewSet, PetImageViewSet

app_name = 'listings'

router = DefaultRouter()
router.register(r'categories', PetCategoryViewSet, basename='category')
router.register(r'listings', PetListingViewSet, basename='listing')
router.register(r'images', PetImageViewSet, basename='image')

urlpatterns = [
    path('', include(router.urls)),
]
