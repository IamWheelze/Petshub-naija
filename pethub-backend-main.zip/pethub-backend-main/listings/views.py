"""
Views for the listings app.
"""

from rest_framework import viewsets, permissions, status, filters
from rest_framework.decorators import action
from rest_framework.response import Response
from django_filters.rest_framework import DjangoFilterBackend
from django.db.models import F

from .models import PetCategory, PetListing, PetImage
from .serializers import (
    PetCategorySerializer,
    PetListingSerializer,
    PetListingListSerializer,
    PetImageSerializer,
)
from accounts.permissions import IsVerifiedVendor, IsOwnerOrReadOnly


class PetCategoryViewSet(viewsets.ReadOnlyModelViewSet):
    """
    ViewSet for pet categories (read-only).

    GET /api/listings/categories/
    GET /api/listings/categories/{id}/
    """
    queryset = PetCategory.objects.filter(is_active=True)
    serializer_class = PetCategorySerializer
    permission_classes = [permissions.AllowAny]
    lookup_field = 'slug'


class PetListingViewSet(viewsets.ModelViewSet):
    """
    ViewSet for pet listings with full CRUD operations.

    List: GET /api/listings/
    Create: POST /api/listings/ (verified vendors only)
    Retrieve: GET /api/listings/{id}/
    Update: PUT/PATCH /api/listings/{id}/ (owner only)
    Delete: DELETE /api/listings/{id}/ (owner only)

    Filters:
    - ?category=<slug>
    - ?min_price=<amount>
    - ?max_price=<amount>
    - ?location=<location>
    - ?is_sold=true/false
    - ?search=<term> (searches title, description, breed)
    - ?ordering=price,-created_at,views_count
    """
    queryset = PetListing.objects.select_related('vendor', 'category').prefetch_related('images').all()
    permission_classes = [permissions.IsAuthenticatedOrReadOnly]
    filter_backends = [DjangoFilterBackend, filters.SearchFilter, filters.OrderingFilter]
    filterset_fields = ['category__slug', 'location', 'is_sold']
    search_fields = ['title', 'description', 'breed']
    ordering_fields = ['price', 'created_at', 'views_count']
    ordering = ['-created_at']

    def get_serializer_class(self):
        """Use different serializers for list vs detail views."""
        if self.action == 'list':
            return PetListingListSerializer
        return PetListingSerializer

    def get_permissions(self):
        """
        Set permissions based on action.
        - Create: Verified vendors only
        - Update/Delete: Owner only
        - List/Retrieve: Anyone
        """
        if self.action == 'create':
            return [permissions.IsAuthenticated(), IsVerifiedVendor()]
        elif self.action in ['update', 'partial_update', 'destroy']:
            return [permissions.IsAuthenticated(), IsOwnerOrReadOnly()]
        return [permissions.AllowAny()]

    def get_queryset(self):
        """
        Customize queryset with additional filters.
        """
        queryset = super().get_queryset()

        # Filter by price range
        min_price = self.request.query_params.get('min_price')
        max_price = self.request.query_params.get('max_price')

        if min_price:
            queryset = queryset.filter(price__gte=min_price)
        if max_price:
            queryset = queryset.filter(price__lte=max_price)

        # Show only active listings to non-owners
        if self.action == 'list' and not self.request.user.is_staff:
            # If user is authenticated, show their own listings regardless of status
            if self.request.user.is_authenticated:
                queryset = queryset.filter(
                    is_active=True
                ) | queryset.filter(vendor=self.request.user)
            else:
                queryset = queryset.filter(is_active=True)

        return queryset

    def perform_create(self, serializer):
        """Set the vendor to the current user."""
        serializer.save(vendor=self.request.user)

    def retrieve(self, request, *args, **kwargs):
        """Increment view count when retrieving a listing."""
        instance = self.get_object()

        # Increment views count (except for owner)
        if not request.user.is_authenticated or request.user != instance.vendor:
            PetListing.objects.filter(pk=instance.pk).update(views_count=F('views_count') + 1)
            instance.refresh_from_db()

        serializer = self.get_serializer(instance)
        return Response(serializer.data)

    @action(detail=True, methods=['post'], permission_classes=[permissions.IsAuthenticated, IsOwnerOrReadOnly])
    def mark_as_sold(self, request, pk=None):
        """
        Mark a listing as sold.

        POST /api/listings/{id}/mark_as_sold/
        """
        listing = self.get_object()
        listing.is_sold = True
        listing.is_active = False
        listing.save(update_fields=['is_sold', 'is_active'])

        return Response(
            {"message": "Listing marked as sold."},
            status=status.HTTP_200_OK
        )

    @action(detail=True, methods=['post'], permission_classes=[permissions.IsAuthenticated, IsOwnerOrReadOnly])
    def reactivate(self, request, pk=None):
        """
        Reactivate a listing.

        POST /api/listings/{id}/reactivate/
        """
        listing = self.get_object()
        listing.is_active = True
        listing.is_sold = False
        listing.save(update_fields=['is_active', 'is_sold'])

        return Response(
            {"message": "Listing reactivated."},
            status=status.HTTP_200_OK
        )


class PetImageViewSet(viewsets.ModelViewSet):
    """
    ViewSet for pet images.

    List: GET /api/listings/{listing_id}/images/
    Create: POST /api/listings/{listing_id}/images/
    Update: PUT/PATCH /api/listings/images/{id}/
    Delete: DELETE /api/listings/images/{id}/
    """
    queryset = PetImage.objects.all()
    serializer_class = PetImageSerializer
    permission_classes = [permissions.IsAuthenticatedOrReadOnly]

    def get_permissions(self):
        """Owner can modify, others can only read."""
        if self.action in ['create', 'update', 'partial_update', 'destroy']:
            return [permissions.IsAuthenticated(), IsOwnerOrReadOnly()]
        return [permissions.AllowAny()]

    def perform_create(self, serializer):
        """Create image for a specific listing."""
        listing_id = self.request.data.get('listing')
        try:
            listing = PetListing.objects.get(pk=listing_id)
            # Check ownership
            if listing.vendor != self.request.user:
                raise permissions.PermissionDenied("You can only add images to your own listings.")

            serializer.save(listing=listing)
        except PetListing.DoesNotExist:
            raise ValueError("Listing not found.")

    @action(detail=True, methods=['post'], permission_classes=[permissions.IsAuthenticated])
    def set_as_main(self, request, pk=None):
        """
        Set this image as the main image for the listing.

        POST /api/listings/images/{id}/set_as_main/
        """
        image = self.get_object()

        # Check ownership
        if image.listing.vendor != request.user:
            return Response(
                {"error": "You can only modify your own listings."},
                status=status.HTTP_403_FORBIDDEN
            )

        # Remove main flag from other images
        PetImage.objects.filter(listing=image.listing).update(is_main=False)

        # Set this image as main
        image.is_main = True
        image.save(update_fields=['is_main'])

        return Response(
            {"message": "Image set as main."},
            status=status.HTTP_200_OK
        )
