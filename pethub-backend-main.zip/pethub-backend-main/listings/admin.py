"""
Admin configuration for the listings app.
"""

from django.contrib import admin
from django.utils.html import format_html
from .models import PetCategory, PetListing, PetImage


@admin.register(PetCategory)
class PetCategoryAdmin(admin.ModelAdmin):
    """
    Admin for PetCategory model.
    """
    list_display = ['name', 'slug', 'is_active', 'listings_count']
    list_filter = ['is_active']
    search_fields = ['name', 'slug']
    prepopulated_fields = {'slug': ('name',)}
    ordering = ['name']

    def listings_count(self, obj):
        """Get count of active listings in this category."""
        count = obj.listings.filter(is_active=True, is_sold=False).count()
        return count
    listings_count.short_description = 'Active Listings'


class PetImageInline(admin.TabularInline):
    """
    Inline admin for pet images.
    """
    model = PetImage
    extra = 1
    fields = ['image', 'is_main', 'order']
    readonly_fields = ['uploaded_at']


@admin.register(PetListing)
class PetListingAdmin(admin.ModelAdmin):
    """
    Admin for PetListing model.
    """
    list_display = [
        'title',
        'vendor',
        'category',
        'price',
        'location',
        'status_badge',
        'views_count',
        'created_at',
    ]
    list_filter = ['category', 'is_active', 'is_sold', 'created_at']
    search_fields = ['title', 'description', 'breed', 'vendor__email', 'vendor__first_name', 'vendor__last_name']
    readonly_fields = ['views_count', 'created_at', 'updated_at']
    ordering = ['-created_at']
    inlines = [PetImageInline]

    fieldsets = (
        ('Basic Information', {
            'fields': ('vendor', 'category', 'title', 'description')
        }),
        ('Pet Details', {
            'fields': ('breed', 'age', 'price', 'location')
        }),
        ('Status', {
            'fields': ('is_active', 'is_sold', 'views_count')
        }),
        ('Timestamps', {
            'fields': ('created_at', 'updated_at')
        }),
    )

    actions = ['activate_listings', 'deactivate_listings']

    def status_badge(self, obj):
        """Display status with color badge."""
        if obj.is_sold:
            color = '#DC3545'  # Red
            text = 'SOLD'
        elif obj.is_active:
            color = '#28A745'  # Green
            text = 'ACTIVE'
        else:
            color = '#6C757D'  # Gray
            text = 'INACTIVE'

        return format_html(
            '<span style="background-color: {}; color: white; padding: 3px 10px; border-radius: 3px;">{}</span>',
            color,
            text
        )
    status_badge.short_description = 'Status'

    def activate_listings(self, request, queryset):
        """Bulk activate listings."""
        updated = queryset.filter(is_sold=False).update(is_active=True)
        self.message_user(request, f'{updated} listing(s) activated.')
    activate_listings.short_description = 'Activate selected listings'

    def deactivate_listings(self, request, queryset):
        """Bulk deactivate listings."""
        updated = queryset.update(is_active=False)
        self.message_user(request, f'{updated} listing(s) deactivated.')
    deactivate_listings.short_description = 'Deactivate selected listings'


@admin.register(PetImage)
class PetImageAdmin(admin.ModelAdmin):
    """
    Admin for PetImage model.
    """
    list_display = ['listing', 'image_preview', 'is_main', 'order', 'uploaded_at']
    list_filter = ['is_main', 'uploaded_at']
    search_fields = ['listing__title']
    ordering = ['listing', 'order']

    def image_preview(self, obj):
        """Display image preview."""
        if obj.image:
            return format_html(
                '<img src="{}" style="max-width: 100px; max-height: 100px;" />',
                obj.image.url
            )
        return '-'
    image_preview.short_description = 'Preview'
