"""
Models for pet listings and categories.
"""

from django.db import models
from django.utils.translation import gettext_lazy as _
from django.core.validators import MinValueValidator
from django.conf import settings


class PetCategory(models.Model):
    """
    Categories for pet listings (e.g., Dog, Cat, Bird, etc.).
    """
    name = models.CharField(_('name'), max_length=100, unique=True)
    slug = models.SlugField(_('slug'), max_length=100, unique=True)
    description = models.TextField(_('description'), blank=True)
    icon = models.ImageField(_('icon'), upload_to='category_icons/', blank=True, null=True)
    is_active = models.BooleanField(_('is active'), default=True)
    created_at = models.DateTimeField(_('created at'), auto_now_add=True)
    updated_at = models.DateTimeField(_('updated at'), auto_now=True)

    class Meta:
        verbose_name = _('pet category')
        verbose_name_plural = _('pet categories')
        ordering = ['name']

    def __str__(self):
        return self.name


class PetListing(models.Model):
    """
    Pet listing created by verified vendors.
    """
    vendor = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name='listings',
        verbose_name=_('vendor')
    )
    category = models.ForeignKey(
        PetCategory,
        on_delete=models.PROTECT,
        related_name='listings',
        verbose_name=_('category')
    )
    title = models.CharField(_('title'), max_length=255)
    description = models.TextField(_('description'))
    breed = models.CharField(_('breed'), max_length=100)
    age = models.CharField(
        _('age'),
        max_length=50,
        help_text=_('e.g., "6 months", "2 years", "Puppy"')
    )
    price = models.DecimalField(
        _('price'),
        max_digits=10,
        decimal_places=2,
        validators=[MinValueValidator(0)],
        help_text=_('Price in Nigerian Naira (₦)')
    )
    location = models.CharField(
        _('location'),
        max_length=255,
        help_text=_('City or State')
    )
    is_active = models.BooleanField(_('is active'), default=True)
    is_sold = models.BooleanField(_('is sold'), default=False)
    views_count = models.PositiveIntegerField(_('views count'), default=0)
    created_at = models.DateTimeField(_('created at'), auto_now_add=True)
    updated_at = models.DateTimeField(_('updated at'), auto_now=True)

    class Meta:
        verbose_name = _('pet listing')
        verbose_name_plural = _('pet listings')
        ordering = ['-created_at']
        indexes = [
            models.Index(fields=['-created_at']),
            models.Index(fields=['category', '-created_at']),
            models.Index(fields=['vendor', '-created_at']),
            models.Index(fields=['is_active', 'is_sold']),
        ]

    def __str__(self):
        return f"{self.title} - {self.category.name}"

    def increment_views(self):
        """Increment the views count for this listing."""
        self.views_count += 1
        self.save(update_fields=['views_count'])

    @property
    def main_image(self):
        """Get the main (first) image for this listing."""
        return self.images.first()

    @property
    def is_available(self):
        """Check if listing is available for purchase."""
        return self.is_active and not self.is_sold


class PetImage(models.Model):
    """
    Images for pet listings. Each listing can have multiple images.
    """
    listing = models.ForeignKey(
        PetListing,
        on_delete=models.CASCADE,
        related_name='images',
        verbose_name=_('listing')
    )
    image = models.ImageField(
        _('image'),
        upload_to='listing_images/',
        help_text=_('Pet image (max 5MB)')
    )
    is_main = models.BooleanField(_('is main image'), default=False)
    order = models.PositiveSmallIntegerField(_('order'), default=0)
    uploaded_at = models.DateTimeField(_('uploaded at'), auto_now_add=True)

    class Meta:
        verbose_name = _('pet image')
        verbose_name_plural = _('pet images')
        ordering = ['order', 'uploaded_at']
        indexes = [
            models.Index(fields=['listing', 'order']),
        ]

    def __str__(self):
        return f"Image for {self.listing.title}"

    def save(self, *args, **kwargs):
        """Ensure only one main image per listing."""
        if self.is_main:
            # Set all other images of this listing to not main
            PetImage.objects.filter(listing=self.listing, is_main=True).update(is_main=False)
        super().save(*args, **kwargs)
