"""
Serializers for the listings app.
"""

from rest_framework import serializers
from .models import PetCategory, PetListing, PetImage
from accounts.serializers import UserSerializer


class PetCategorySerializer(serializers.ModelSerializer):
    """
    Serializer for pet categories.
    """
    listings_count = serializers.SerializerMethodField()

    class Meta:
        model = PetCategory
        fields = ['id', 'name', 'slug', 'icon', 'description', 'is_active', 'listings_count']
        read_only_fields = ['id', 'slug']

    def get_listings_count(self, obj):
        """Get count of active listings in this category."""
        return obj.listings.filter(is_active=True, is_sold=False).count()


class PetImageSerializer(serializers.ModelSerializer):
    """
    Serializer for pet images.
    """
    class Meta:
        model = PetImage
        fields = ['id', 'image', 'is_main', 'order', 'created_at']
        read_only_fields = ['id', 'created_at']


class PetListingSerializer(serializers.ModelSerializer):
    """
    Serializer for pet listings (full details).
    """
    vendor_name = serializers.CharField(source='vendor.get_full_name', read_only=True)
    vendor_email = serializers.EmailField(source='vendor.email', read_only=True)
    category_name = serializers.CharField(source='category.name', read_only=True)
    images = PetImageSerializer(many=True, read_only=True)
    uploaded_images = serializers.ListField(
        child=serializers.ImageField(allow_empty_file=False),
        write_only=True,
        required=False
    )

    class Meta:
        model = PetListing
        fields = [
            'id',
            'vendor',
            'vendor_name',
            'vendor_email',
            'category',
            'category_name',
            'title',
            'description',
            'breed',
            'age',
            'price',
            'location',
            'is_active',
            'is_sold',
            'views_count',
            'images',
            'uploaded_images',
            'created_at',
            'updated_at',
        ]
        read_only_fields = ['id', 'vendor', 'views_count', 'is_sold', 'created_at', 'updated_at']

    def create(self, validated_data):
        """Create listing with images."""
        uploaded_images = validated_data.pop('uploaded_images', [])
        listing = PetListing.objects.create(**validated_data)

        # Create images
        for idx, image in enumerate(uploaded_images):
            PetImage.objects.create(
                listing=listing,
                image=image,
                is_main=(idx == 0),  # First image is main
                order=idx
            )

        return listing

    def update(self, instance, validated_data):
        """Update listing and optionally add more images."""
        uploaded_images = validated_data.pop('uploaded_images', [])

        # Update listing fields
        for attr, value in validated_data.items():
            setattr(instance, attr, value)
        instance.save()

        # Add new images if provided
        if uploaded_images:
            current_count = instance.images.count()
            for idx, image in enumerate(uploaded_images):
                PetImage.objects.create(
                    listing=instance,
                    image=image,
                    is_main=False,  # Don't override existing main image
                    order=current_count + idx
                )

        return instance


class PetListingListSerializer(serializers.ModelSerializer):
    """
    Serializer for pet listing list view (summary only).
    """
    vendor_name = serializers.CharField(source='vendor.get_full_name', read_only=True)
    category_name = serializers.CharField(source='category.name', read_only=True)
    main_image = serializers.SerializerMethodField()

    class Meta:
        model = PetListing
        fields = [
            'id',
            'vendor_name',
            'category_name',
            'title',
            'breed',
            'age',
            'price',
            'location',
            'is_sold',
            'views_count',
            'main_image',
            'created_at',
        ]

    def get_main_image(self, obj):
        """Get the main image URL."""
        main_image = obj.images.filter(is_main=True).first()
        if main_image:
            request = self.context.get('request')
            if request:
                return request.build_absolute_uri(main_image.image.url)
            return main_image.image.url
        return None
