# PetHub Backend API

A comprehensive Django REST Framework backend for the PetHub marketplace platform - Nigeria's trusted online marketplace for pets and pet-related services.

## 📋 Project Overview

PetHub is a B2C/C2C marketplace that connects verified pet vendors with buyers across Nigeria. The platform provides a secure, user-friendly environment for listing, discovering, and purchasing pets.

### Key Features

- 🔐 **JWT-based Authentication** - Secure token-based auth with refresh tokens
- 👥 **Role-Based Access Control** - Separate roles for Buyers, Vendors, and Administrators
- ✅ **Vendor Verification System** - Manual admin approval workflow for sellers
- 🐕 **Pet Listings Management** - Full CRUD operations with categories and images
- 🔍 **Advanced Search & Filtering** - Filter by category, location, price range
- 💬 **Real-Time Messaging** - WebSocket-based chat between buyers and vendors
- 💳 **Payment Integration** - Paystack gateway for secure transactions
- 📦 **Order Management** - Complete order tracking and status management
- ⭐ **Review System** - Buyers can rate and review vendors
- 📧 **Email Notifications** - Automated emails for important actions
- 📚 **API Documentation** - Auto-generated Swagger/OpenAPI documentation

## 🛠️ Technology Stack

### Core Framework
- **Django 5.2** - High-level Python web framework
- **Django REST Framework 3.16** - Powerful toolkit for building Web APIs
- **PostgreSQL 15+** - Robust relational database

### Authentication & Security
- **djangorestframework-simplejwt** - JSON Web Token authentication
- **django-cors-headers** - Cross-Origin Resource Sharing
- **django-csp** - Content Security Policy headers

### Real-Time Features
- **Django Channels 4.0** - WebSocket support for real-time messaging
- **channels-redis** - Redis channel layer backend
- **Daphne** - ASGI server for Django Channels

### Background Tasks
- **Celery 5.3** - Distributed task queue
- **Redis 7.0** - Message broker and result backend

### Additional Libraries
- **django-filter** - Dynamic QuerySet filtering
- **Pillow** - Image processing
- **drf-spectacular** - OpenAPI 3.0 schema generation
- **python-decouple** - Environment variable management
- **django-anymail** - Email backend integration (SendGrid)

## 📁 Project Structure

```
pethub-backend/
├── pethub_project/          # Main project configuration
│   ├── settings.py          # Django settings
│   ├── urls.py              # Root URL configuration
│   ├── asgi.py              # ASGI configuration for Channels
│   └── wsgi.py              # WSGI configuration
├── accounts/                # User authentication and profiles
│   ├── models.py            # User and VendorProfile models
│   ├── serializers.py       # DRF serializers
│   ├── views.py             # API views
│   ├── permissions.py       # Custom permissions
│   ├── admin.py             # Django admin configuration
│   └── urls.py              # App URLs
├── listings/                # Pet listings management
│   ├── models.py            # PetCategory, PetListing, PetImage
│   ├── serializers.py       # DRF serializers
│   ├── views.py             # API views with filtering
│   ├── admin.py             # Django admin configuration
│   └── urls.py              # App URLs
├── messaging/               # Real-time messaging system
│   ├── models.py            # Conversation and Message models
│   ├── serializers.py       # DRF serializers
│   ├── views.py             # API views
│   ├── consumers.py         # WebSocket consumers
│   ├── routing.py           # WebSocket URL routing
│   └── urls.py              # App URLs
├── orders/                  # Order and payment management
│   ├── models.py            # Order and Review models
│   ├── serializers.py       # DRF serializers
│   ├── views.py             # API views
│   ├── services.py          # Paystack integration
│   ├── admin.py             # Django admin configuration
│   └── urls.py              # App URLs
├── media/                   # User-uploaded files
├── staticfiles/             # Collected static files
├── requirements.txt         # Python dependencies
├── .env.example             # Environment variables template
├── .gitignore               # Git ignore rules
├── manage.py                # Django management script
└── README.md                # This file
```

## 🚀 Getting Started

### Prerequisites

- Python 3.12+
- PostgreSQL 15+
- Redis 7.0+ (for Channels and Celery)
- Git

### Installation

1. **Clone the repository**

```bash
cd pethub-backend
```

2. **Create and activate virtual environment**

```bash
python3 -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
```

3. **Install dependencies**

```bash
pip install -r requirements.txt
```

4. **Set up environment variables**

```bash
cp .env.example .env
```

Edit `.env` and configure the following variables:

```env
# Django Settings
SECRET_KEY=your-secret-key-here
DEBUG=True
ALLOWED_HOSTS=localhost,127.0.0.1

# Database
DB_NAME=pethub_db
DB_USER=your_db_user
DB_PASSWORD=your_db_password
DB_HOST=localhost
DB_PORT=5432

# JWT
ACCESS_TOKEN_LIFETIME=60
REFRESH_TOKEN_LIFETIME=1440

# Email (SendGrid or SMTP)
EMAIL_BACKEND=anymail.backends.sendgrid.EmailBackend
SENDGRID_API_KEY=your-sendgrid-api-key
DEFAULT_FROM_EMAIL=noreply@pethub.ng

# Redis
REDIS_HOST=localhost
REDIS_PORT=6379

# Celery
CELERY_BROKER_URL=redis://localhost:6379/0
CELERY_RESULT_BACKEND=redis://localhost:6379/0

# Paystack
PAYSTACK_SECRET_KEY=sk_test_your_secret_key
PAYSTACK_PUBLIC_KEY=pk_test_your_public_key
PAYSTACK_WEBHOOK_SECRET=your_webhook_secret

# CORS
CORS_ALLOWED_ORIGINS=http://localhost:3000,http://localhost:5173

# Frontend URL
FRONTEND_URL=http://localhost:3000
```

5. **Set up PostgreSQL database**

```bash
# Login to PostgreSQL
psql -U postgres

# Create database and user
CREATE DATABASE pethub_db;
CREATE USER pethub_user WITH PASSWORD 'your_password';
ALTER ROLE pethub_user SET client_encoding TO 'utf8';
ALTER ROLE pethub_user SET default_transaction_isolation TO 'read committed';
ALTER ROLE pethub_user SET timezone TO 'Africa/Lagos';
GRANT ALL PRIVILEGES ON DATABASE pethub_db TO pethub_user;
\q
```

6. **Run migrations**

```bash
python manage.py makemigrations
python manage.py migrate
```

7. **Create superuser**

```bash
python manage.py createsuperuser
```

8. **Collect static files**

```bash
python manage.py collectstatic --noinput
```

9. **Run the development server**

For HTTP only:
```bash
python manage.py runserver
```

For WebSocket support (recommended):
```bash
daphne -b 0.0.0.0 -p 8000 pethub_project.asgi:application
```

10. **Start Celery worker (in a new terminal)**

```bash
source venv/bin/activate
celery -A pethub_project worker -l info
```

11. **Start Celery beat (optional, for scheduled tasks)**

```bash
source venv/bin/activate
celery -A pethub_project beat -l info
```

## 🔑 API Endpoints

### Authentication

| Method | Endpoint | Description | Auth Required |
|--------|----------|-------------|---------------|
| POST | `/api/accounts/register/` | Register new user | No |
| POST | `/api/accounts/verify-email/` | Verify email address | No |
| POST | `/api/token/` | Obtain JWT token (login) | No |
| POST | `/api/token/refresh/` | Refresh access token | No |
| POST | `/api/accounts/password-reset/` | Request password reset | No |
| POST | `/api/accounts/password-reset-confirm/` | Confirm password reset | No |

### User Profile

| Method | Endpoint | Description | Auth Required |
|--------|----------|-------------|---------------|
| GET | `/api/accounts/profile/` | Get user profile | Yes |
| PUT/PATCH | `/api/accounts/profile/` | Update user profile | Yes |
| POST | `/api/accounts/vendor-profile/` | Create vendor profile | Yes (Vendor) |
| GET | `/api/accounts/vendor-profile/:id/` | Get vendor profile | No |

### Pet Listings

| Method | Endpoint | Description | Auth Required |
|--------|----------|-------------|---------------|
| GET | `/api/listings/categories/` | List all categories | No |
| GET | `/api/listings/` | List all listings (with filters) | No |
| POST | `/api/listings/` | Create new listing | Yes (Verified Vendor) |
| GET | `/api/listings/:id/` | Get listing details | No |
| PUT/PATCH | `/api/listings/:id/` | Update listing | Yes (Owner) |
| DELETE | `/api/listings/:id/` | Delete listing | Yes (Owner) |

**Query Parameters for Listings:**
- `category` - Filter by category slug
- `location` - Filter by location
- `min_price` - Minimum price
- `max_price` - Maximum price
- `search` - Search in title, description, breed
- `ordering` - Sort by field (e.g., `-created_at`, `price`)

### Messaging

| Method | Endpoint | Description | Auth Required |
|--------|----------|-------------|---------------|
| GET | `/api/messaging/conversations/` | List conversations | Yes |
| POST | `/api/messaging/conversations/` | Create conversation | Yes |
| GET | `/api/messaging/conversations/:id/` | Get conversation details | Yes |
| GET | `/api/messaging/conversations/:id/messages/` | List messages | Yes |
| POST | `/api/messaging/conversations/:id/messages/` | Send message | Yes |

**WebSocket Endpoint:**
```
ws://localhost:8000/ws/chat/<conversation_id>/?token=<jwt_token>
```

### Orders & Payments

| Method | Endpoint | Description | Auth Required |
|--------|----------|-------------|---------------|
| GET | `/api/orders/` | List user orders | Yes |
| POST | `/api/orders/create/` | Create new order | Yes (Buyer) |
| GET | `/api/orders/:id/` | Get order details | Yes |
| POST | `/api/orders/:id/complete/` | Mark order as completed | Yes (Vendor) |
| POST | `/api/orders/:id/review/` | Review order | Yes (Buyer) |
| POST | `/api/orders/webhook/` | Paystack webhook | No (Verified) |

### API Documentation

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/docs/` | Swagger UI documentation |
| GET | `/api/schema/` | OpenAPI schema (JSON) |

## 🔒 Authentication

The API uses JWT (JSON Web Tokens) for authentication. To authenticate:

1. **Register a new account**

```bash
curl -X POST http://localhost:8000/api/accounts/register/ \
  -H "Content-Type: application/json" \
  -d '{
    "email": "user@example.com",
    "password": "SecurePassword123!",
    "confirm_password": "SecurePassword123!",
    "first_name": "John",
    "last_name": "Doe",
    "phone_number": "+2348012345678",
    "role": "buyer"
  }'
```

2. **Verify email** (check console for token)

```bash
curl -X POST http://localhost:8000/api/accounts/verify-email/ \
  -H "Content-Type: application/json" \
  -d '{"token": "verification_token_here"}'
```

3. **Obtain JWT token (login)**

```bash
curl -X POST http://localhost:8000/api/token/ \
  -H "Content-Type: application/json" \
  -d '{
    "email": "user@example.com",
    "password": "SecurePassword123!"
  }'
```

Response:
```json
{
  "access": "eyJ0eXAiOiJKV1QiLCJhbGc...",
  "refresh": "eyJ0eXAiOiJKV1QiLCJhbGc..."
}
```

4. **Use the access token in subsequent requests**

```bash
curl -X GET http://localhost:8000/api/accounts/profile/ \
  -H "Authorization: Bearer eyJ0eXAiOiJKV1QiLCJhbGc..."
```

5. **Refresh the token when it expires**

```bash
curl -X POST http://localhost:8000/api/token/refresh/ \
  -H "Content-Type: application/json" \
  -d '{"refresh": "eyJ0eXAiOiJKV1QiLCJhbGc..."}'
```

## 👥 User Roles & Permissions

### Guest (Unauthenticated)
- View public listings
- Search and filter listings
- View static pages
- Register and login

### Buyer (Authenticated)
- All guest permissions
- Save/favorite listings
- Contact vendors via messaging
- Make purchases
- View order history
- Leave reviews

### Vendor (Authenticated & Verified)
- All buyer permissions
- Create and manage listings
- Upload multiple images per listing
- View sales history
- Respond to buyer messages
- Manage orders

### Administrator (Staff)
- Access Django admin panel
- Verify/reject vendor applications
- Moderate listings
- Manage categories
- View all orders and conversations
- System configuration

## 💳 Payment Integration (Paystack)

### Payment Flow

1. **Initialize Transaction**

```python
POST /api/orders/create/
{
  "listing_id": "uuid-here"
}
```

Response includes Paystack authorization URL:
```json
{
  "order_id": "uuid",
  "payment_url": "https://checkout.paystack.com/...",
  "reference": "ref_123456"
}
```

2. **Redirect user to payment URL**

3. **Paystack processes payment and redirects back**

4. **Webhook notification**

Paystack sends webhook to `/api/orders/webhook/`:
```json
{
  "event": "charge.success",
  "data": {
    "reference": "ref_123456",
    "status": "success"
  }
}
```

5. **Order status updated automatically**

### Webhook Setup

1. Configure webhook URL in Paystack dashboard:
   ```
   https://your-domain.com/api/orders/webhook/
   ```

2. Add webhook secret to `.env`:
   ```env
   PAYSTACK_WEBHOOK_SECRET=your_webhook_secret
   ```

3. Webhook will verify signature and update order status

## 📧 Email Configuration

### Using SendGrid (Recommended)

```env
EMAIL_BACKEND=anymail.backends.sendgrid.EmailBackend
SENDGRID_API_KEY=your-sendgrid-api-key
DEFAULT_FROM_EMAIL=noreply@pethub.ng
```

### Using SMTP (Alternative)

```env
EMAIL_BACKEND=django.core.mail.backends.smtp.EmailBackend
EMAIL_HOST=smtp.gmail.com
EMAIL_PORT=587
EMAIL_USE_TLS=True
EMAIL_HOST_USER=your-email@gmail.com
EMAIL_HOST_PASSWORD=your-app-password
DEFAULT_FROM_EMAIL=noreply@pethub.ng
```

### Email Templates

Emails are sent for the following events:
- User registration (verification link)
- Password reset
- Vendor approval/rejection
- Order confirmation
- Payment confirmation

## 🧪 Testing

Run the test suite:

```bash
python manage.py test
```

Run tests with coverage:

```bash
pip install coverage
coverage run --source='.' manage.py test
coverage report
coverage html  # Generate HTML report
```

Run specific test modules:

```bash
python manage.py test accounts.tests
python manage.py test listings.tests
```

## 🚀 Deployment

### Production Checklist

1. **Environment Configuration**
   ```env
   DEBUG=False
   SECRET_KEY=<strong-random-key>
   ALLOWED_HOSTS=yourdomain.com,www.yourdomain.com
   ```

2. **Database Setup**
   - Use managed PostgreSQL service (e.g., AWS RDS, DigitalOcean)
   - Enable SSL connections
   - Set up automated backups

3. **Redis Setup**
   - Use managed Redis service (e.g., AWS ElastiCache, Redis Cloud)
   - Enable persistence

4. **Static Files**
   ```bash
   python manage.py collectstatic
   ```
   - Serve via CDN (Cloudflare, AWS CloudFront)
   - Or use WhiteNoise middleware

5. **Media Files**
   - Configure cloud storage (AWS S3, Google Cloud Storage)
   - Use Django-storages package

6. **SSL/TLS**
   - Obtain certificate (Let's Encrypt, Cloudflare)
   - Configure HTTPS redirect
   ```env
   SECURE_SSL_REDIRECT=True
   SESSION_COOKIE_SECURE=True
   CSRF_COOKIE_SECURE=True
   ```

7. **Security**
   ```bash
   python manage.py check --deploy
   ```

8. **Process Management**
   - Use Supervisor or systemd for process management
   - Configure separate services for:
     - Daphne (ASGI server)
     - Celery worker
     - Celery beat

9. **Monitoring & Logging**
   - Set up Sentry for error tracking
   - Configure application logging
   - Set up performance monitoring

10. **Backups**
    - Automated database backups
    - Media files backup
    - Test restoration procedures

### Deployment Platforms

**Recommended platforms:**
- **Heroku** - Easy deployment with add-ons
- **DigitalOcean App Platform** - Simple and affordable
- **AWS Elastic Beanstalk** - Scalable and managed
- **Railway** - Modern deployment platform
- **Render** - Free tier available

### Example: Deploying to Heroku

1. Install Heroku CLI and login

2. Create `Procfile`:
```
web: daphne -b 0.0.0.0 -p $PORT pethub_project.asgi:application
worker: celery -A pethub_project worker -l info
beat: celery -A pethub_project beat -l info
```

3. Create `runtime.txt`:
```
python-3.12.3
```

4. Update `requirements.txt`:
```bash
pip freeze > requirements.txt
```

5. Deploy:
```bash
heroku create pethub-api
heroku addons:create heroku-postgresql:essential-0
heroku addons:create heroku-redis:mini
heroku config:set SECRET_KEY=<your-secret-key>
git push heroku main
heroku run python manage.py migrate
heroku run python manage.py createsuperuser
```

## 📊 Database Schema

### Core Tables

- **accounts_user** - User accounts with role
- **accounts_vendorprofile** - Extended vendor information
- **listings_petcategory** - Pet categories
- **listings_petlisting** - Pet listings
- **listings_petimage** - Listing images
- **messaging_conversation** - Buyer-vendor conversations
- **messaging_message** - Chat messages
- **orders_order** - Purchase orders
- **orders_review** - Order reviews

See `IMPLEMENTATION_STATUS.md` for detailed schema information.

## 🛡️ Security Best Practices

1. **Authentication**
   - JWT tokens with expiration
   - Refresh token rotation
   - Password hashing with PBKDF2

2. **Authorization**
   - Role-based access control
   - Object-level permissions
   - Vendor verification required for listings

3. **Data Protection**
   - CSRF protection enabled
   - CORS properly configured
   - SQL injection prevention (Django ORM)
   - XSS protection
   - Content Security Policy headers

4. **Rate Limiting**
   - API endpoints throttled
   - Anonymous: 100 requests/hour
   - Authenticated: 1000 requests/hour

5. **File Uploads**
   - File size limits enforced
   - File type validation
   - Secure file storage

## 📝 API Response Format

### Success Response

```json
{
  "id": 1,
  "email": "user@example.com",
  "first_name": "John",
  "last_name": "Doe"
}
```

### Error Response

```json
{
  "detail": "Error message here"
}
```

### Validation Errors

```json
{
  "email": ["This field is required."],
  "password": ["This password is too common."]
}
```

### Paginated Response

```json
{
  "count": 100,
  "next": "http://api.example.com/listings/?page=2",
  "previous": null,
  "results": [...]
}
```

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/AmazingFeature`)
3. Commit your changes (`git commit -m 'Add some AmazingFeature'`)
4. Push to the branch (`git push origin feature/AmazingFeature`)
5. Open a Pull Request

## 📄 License

This project is proprietary software. All rights reserved.

## 📞 Support

For support and questions:
- Email: admin@pethub.ng
- Documentation: See IMPLEMENTATION_STATUS.md

## 🙏 Acknowledgments

- Django and DRF communities
- Paystack for payment integration
- All contributors and testers

---

**Built with ❤️ for pet lovers in Nigeria**
