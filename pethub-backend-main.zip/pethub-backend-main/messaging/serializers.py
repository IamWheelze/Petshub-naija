"""
Serializers for the messaging app.
"""

from rest_framework import serializers
from django.contrib.auth import get_user_model
from .models import Conversation, Message
from listings.models import PetListing

User = get_user_model()


class MessageSerializer(serializers.ModelSerializer):
    """
    Serializer for messages.
    """
    sender_name = serializers.CharField(source='sender.get_full_name', read_only=True)
    sender_email = serializers.EmailField(source='sender.email', read_only=True)

    class Meta:
        model = Message
        fields = [
            'id',
            'conversation',
            'sender',
            'sender_name',
            'sender_email',
            'body',
            'is_read',
            'read_at',
            'timestamp',
        ]
        read_only_fields = ['id', 'sender', 'is_read', 'read_at', 'timestamp']


class ConversationSerializer(serializers.ModelSerializer):
    """
    Serializer for conversations.
    """
    buyer_name = serializers.CharField(source='buyer.get_full_name', read_only=True)
    vendor_name = serializers.CharField(source='vendor.get_full_name', read_only=True)
    listing_title = serializers.CharField(source='listing.title', read_only=True, allow_null=True)
    last_message = serializers.SerializerMethodField()
    unread_count = serializers.SerializerMethodField()

    class Meta:
        model = Conversation
        fields = [
            'id',
            'buyer',
            'buyer_name',
            'vendor',
            'vendor_name',
            'listing',
            'listing_title',
            'last_message',
            'unread_count',
            'created_at',
            'updated_at',
        ]
        read_only_fields = ['id', 'buyer', 'vendor', 'created_at', 'updated_at']

    def get_last_message(self, obj):
        """Get the last message in the conversation."""
        last_message = obj.messages.order_by('-timestamp').first()
        if last_message:
            return {
                'body': last_message.body,
                'sender': last_message.sender.get_full_name(),
                'timestamp': last_message.timestamp,
            }
        return None

    def get_unread_count(self, obj):
        """Get unread message count for the current user."""
        request = self.context.get('request')
        if request and request.user.is_authenticated:
            return obj.get_unread_count(request.user)
        return 0


class ConversationCreateSerializer(serializers.ModelSerializer):
    """
    Serializer for creating conversations.
    """
    vendor_id = serializers.IntegerField(write_only=True)
    listing_id = serializers.IntegerField(write_only=True, required=False, allow_null=True)

    class Meta:
        model = Conversation
        fields = ['vendor_id', 'listing_id']

    def validate_vendor_id(self, value):
        """Validate that vendor exists and is a vendor."""
        try:
            vendor = User.objects.get(pk=value)
            if not vendor.is_vendor:
                raise serializers.ValidationError("The specified user is not a vendor.")
            return value
        except User.DoesNotExist:
            raise serializers.ValidationError("Vendor not found.")

    def validate_listing_id(self, value):
        """Validate that listing exists if provided."""
        if value:
            try:
                PetListing.objects.get(pk=value)
                return value
            except PetListing.DoesNotExist:
                raise serializers.ValidationError("Listing not found.")
        return value

    def validate(self, attrs):
        """Validate that buyer is not creating conversation with themselves."""
        request = self.context.get('request')
        if request.user.id == attrs['vendor_id']:
            raise serializers.ValidationError("You cannot start a conversation with yourself.")
        return attrs

    def create(self, validated_data):
        """Create or retrieve existing conversation."""
        request = self.context.get('request')
        buyer = request.user
        vendor_id = validated_data['vendor_id']
        listing_id = validated_data.get('listing_id')

        # Check if conversation already exists
        conversation = Conversation.objects.filter(
            buyer=buyer,
            vendor_id=vendor_id,
            listing_id=listing_id
        ).first()

        if conversation:
            return conversation

        # Create new conversation
        conversation = Conversation.objects.create(
            buyer=buyer,
            vendor_id=vendor_id,
            listing_id=listing_id
        )

        return conversation


class MessageCreateSerializer(serializers.ModelSerializer):
    """
    Serializer for creating messages.
    """
    class Meta:
        model = Message
        fields = ['conversation', 'body']

    def validate_conversation(self, value):
        """Validate that user is part of the conversation."""
        request = self.context.get('request')
        if request.user not in [value.buyer, value.vendor]:
            raise serializers.ValidationError("You are not part of this conversation.")
        return value

    def create(self, validated_data):
        """Create message and update conversation timestamp."""
        request = self.context.get('request')
        message = Message.objects.create(
            sender=request.user,
            **validated_data
        )

        # Update conversation timestamp
        conversation = validated_data['conversation']
        conversation.save()  # This will update updated_at

        return message
