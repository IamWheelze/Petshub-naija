"""
WebSocket consumers for real-time messaging.
"""

import json
from channels.generic.websocket import AsyncWebsocketConsumer
from channels.db import database_sync_to_async
from django.contrib.auth import get_user_model
from .models import Conversation, Message

User = get_user_model()


class ChatConsumer(AsyncWebsocketConsumer):
    """
    WebSocket consumer for real-time chat messaging.

    URL: ws://<host>/ws/chat/<conversation_id>/
    """

    async def connect(self):
        """
        Handle WebSocket connection.
        """
        self.conversation_id = self.scope['url_route']['kwargs']['conversation_id']
        self.room_group_name = f'chat_{self.conversation_id}'
        self.user = self.scope['user']

        # Verify user is authenticated
        if not self.user.is_authenticated:
            await self.close(code=403)
            return

        # Verify user is part of the conversation
        is_participant = await self.is_conversation_participant()
        if not is_participant:
            await self.close(code=403)
            return

        # Join room group
        await self.channel_layer.group_add(
            self.room_group_name,
            self.channel_name
        )

        await self.accept()

        # Send connection success message
        await self.send(text_data=json.dumps({
            'type': 'connection_established',
            'message': 'Successfully connected to chat'
        }))

    async def disconnect(self, close_code):
        """
        Handle WebSocket disconnection.
        """
        # Leave room group
        if hasattr(self, 'room_group_name'):
            await self.channel_layer.group_discard(
                self.room_group_name,
                self.channel_name
            )

    async def receive(self, text_data):
        """
        Receive message from WebSocket.
        """
        try:
            data = json.loads(text_data)
            message_type = data.get('type', 'chat_message')

            if message_type == 'chat_message':
                body = data.get('body', '').strip()

                if not body:
                    await self.send(text_data=json.dumps({
                        'type': 'error',
                        'message': 'Message body cannot be empty'
                    }))
                    return

                # Save message to database
                message = await self.save_message(body)

                # Send message to room group
                await self.channel_layer.group_send(
                    self.room_group_name,
                    {
                        'type': 'chat_message',
                        'message': {
                            'id': message.id,
                            'conversation_id': str(self.conversation_id),
                            'sender_id': self.user.id,
                            'sender_name': self.user.get_full_name(),
                            'body': message.body,
                            'timestamp': message.timestamp.isoformat(),
                            'is_read': message.is_read,
                        }
                    }
                )

            elif message_type == 'mark_as_read':
                # Mark messages as read
                await self.mark_messages_as_read()

                await self.send(text_data=json.dumps({
                    'type': 'messages_marked_read',
                    'message': 'Messages marked as read'
                }))

            elif message_type == 'typing':
                # Broadcast typing indicator
                await self.channel_layer.group_send(
                    self.room_group_name,
                    {
                        'type': 'user_typing',
                        'user_id': self.user.id,
                        'user_name': self.user.get_full_name(),
                    }
                )

        except json.JSONDecodeError:
            await self.send(text_data=json.dumps({
                'type': 'error',
                'message': 'Invalid JSON'
            }))
        except Exception as e:
            await self.send(text_data=json.dumps({
                'type': 'error',
                'message': f'Error: {str(e)}'
            }))

    async def chat_message(self, event):
        """
        Receive message from room group and send to WebSocket.
        """
        await self.send(text_data=json.dumps({
            'type': 'chat_message',
            'message': event['message']
        }))

    async def user_typing(self, event):
        """
        Receive typing indicator from room group.
        """
        # Don't send typing indicator to the user who is typing
        if event['user_id'] != self.user.id:
            await self.send(text_data=json.dumps({
                'type': 'user_typing',
                'user_id': event['user_id'],
                'user_name': event['user_name'],
            }))

    @database_sync_to_async
    def is_conversation_participant(self):
        """
        Check if user is a participant in the conversation.
        """
        try:
            conversation = Conversation.objects.get(pk=self.conversation_id)
            return self.user in [conversation.buyer, conversation.vendor]
        except Conversation.DoesNotExist:
            return False

    @database_sync_to_async
    def save_message(self, body):
        """
        Save message to database.
        """
        conversation = Conversation.objects.get(pk=self.conversation_id)
        message = Message.objects.create(
            conversation=conversation,
            sender=self.user,
            body=body
        )
        # Update conversation timestamp
        conversation.save()  # This will update updated_at
        return message

    @database_sync_to_async
    def mark_messages_as_read(self):
        """
        Mark all messages in conversation as read for current user.
        """
        conversation = Conversation.objects.get(pk=self.conversation_id)
        conversation.messages.filter(is_read=False).exclude(sender=self.user).update(is_read=True)
