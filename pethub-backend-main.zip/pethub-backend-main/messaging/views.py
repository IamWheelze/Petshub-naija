"""
Views for the messaging app.
"""

from rest_framework import viewsets, permissions, status
from rest_framework.decorators import action
from rest_framework.response import Response
from django.db.models import Q
from django.shortcuts import get_object_or_404

from .models import Conversation, Message
from .serializers import (
    ConversationSerializer,
    ConversationCreateSerializer,
    MessageSerializer,
    MessageCreateSerializer,
)


class ConversationViewSet(viewsets.ModelViewSet):
    """
    ViewSet for conversations.

    List: GET /api/messaging/conversations/
    Create: POST /api/messaging/conversations/
    Retrieve: GET /api/messaging/conversations/{id}/
    """
    permission_classes = [permissions.IsAuthenticated]

    def get_queryset(self):
        """Get conversations where user is buyer or vendor."""
        user = self.request.user
        return Conversation.objects.filter(
            Q(buyer=user) | Q(vendor=user)
        ).select_related('buyer', 'vendor', 'listing').order_by('-updated_at')

    def get_serializer_class(self):
        """Use different serializers for create vs other actions."""
        if self.action == 'create':
            return ConversationCreateSerializer
        return ConversationSerializer

    @action(detail=True, methods=['get'])
    def messages(self, request, pk=None):
        """
        Get all messages in a conversation.

        GET /api/messaging/conversations/{id}/messages/
        """
        conversation = self.get_object()

        # Verify user is part of the conversation
        if request.user not in [conversation.buyer, conversation.vendor]:
            return Response(
                {"error": "You are not part of this conversation."},
                status=status.HTTP_403_FORBIDDEN
            )

        # Get messages
        messages = conversation.messages.select_related('sender').order_by('timestamp')

        # Mark messages as read
        messages.filter(is_read=False).exclude(sender=request.user).update(is_read=True)

        serializer = MessageSerializer(messages, many=True)
        return Response(serializer.data)

    @action(detail=True, methods=['post'])
    def send_message(self, request, pk=None):
        """
        Send a message in a conversation.

        POST /api/messaging/conversations/{id}/send_message/
        {
            "body": "Message text here"
        }
        """
        conversation = self.get_object()

        # Verify user is part of the conversation
        if request.user not in [conversation.buyer, conversation.vendor]:
            return Response(
                {"error": "You are not part of this conversation."},
                status=status.HTTP_403_FORBIDDEN
            )

        # Create message
        data = request.data.copy()
        data['conversation'] = conversation.id

        serializer = MessageCreateSerializer(data=data, context={'request': request})
        serializer.is_valid(raise_exception=True)
        message = serializer.save()

        return Response(
            MessageSerializer(message).data,
            status=status.HTTP_201_CREATED
        )

    @action(detail=True, methods=['post'])
    def mark_as_read(self, request, pk=None):
        """
        Mark all messages in a conversation as read.

        POST /api/messaging/conversations/{id}/mark_as_read/
        """
        conversation = self.get_object()

        # Verify user is part of the conversation
        if request.user not in [conversation.buyer, conversation.vendor]:
            return Response(
                {"error": "You are not part of this conversation."},
                status=status.HTTP_403_FORBIDDEN
            )

        # Mark messages as read
        conversation.messages.filter(is_read=False).exclude(sender=request.user).update(is_read=True)

        return Response(
            {"message": "All messages marked as read."},
            status=status.HTTP_200_OK
        )


class MessageViewSet(viewsets.ReadOnlyModelViewSet):
    """
    ViewSet for messages (read-only via API).
    Messages should be created through ConversationViewSet.send_message or WebSocket.

    List: GET /api/messaging/messages/
    Retrieve: GET /api/messaging/messages/{id}/
    """
    serializer_class = MessageSerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_queryset(self):
        """Get messages from conversations where user is buyer or vendor."""
        user = self.request.user
        return Message.objects.filter(
            Q(conversation__buyer=user) | Q(conversation__vendor=user)
        ).select_related('sender', 'conversation').order_by('-timestamp')
