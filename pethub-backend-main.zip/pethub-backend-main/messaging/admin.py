"""
Admin configuration for the messaging app.
"""

from django.contrib import admin
from django.utils.html import format_html
from .models import Conversation, Message


class MessageInline(admin.TabularInline):
    """
    Inline admin for messages in a conversation.
    """
    model = Message
    extra = 0
    fields = ['sender', 'body', 'is_read', 'timestamp']
    readonly_fields = ['sender', 'timestamp']
    can_delete = False

    def has_add_permission(self, request, obj=None):
        return False


@admin.register(Conversation)
class ConversationAdmin(admin.ModelAdmin):
    """
    Admin for Conversation model.
    """
    list_display = ['id', 'buyer', 'vendor', 'listing', 'message_count', 'created_at', 'updated_at']
    list_filter = ['created_at', 'updated_at']
    search_fields = ['buyer__email', 'vendor__email', 'listing__title']
    readonly_fields = ['created_at', 'updated_at']
    ordering = ['-updated_at']
    inlines = [MessageInline]

    fieldsets = (
        ('Participants', {
            'fields': ('buyer', 'vendor', 'listing')
        }),
        ('Timestamps', {
            'fields': ('created_at', 'updated_at')
        }),
    )

    def message_count(self, obj):
        """Get count of messages in conversation."""
        return obj.messages.count()
    message_count.short_description = 'Messages'


@admin.register(Message)
class MessageAdmin(admin.ModelAdmin):
    """
    Admin for Message model.
    """
    list_display = ['id', 'sender', 'conversation', 'body_preview', 'is_read_badge', 'timestamp']
    list_filter = ['is_read', 'timestamp']
    search_fields = ['sender__email', 'body']
    readonly_fields = ['timestamp', 'read_at']
    ordering = ['-timestamp']

    fieldsets = (
        ('Message Details', {
            'fields': ('conversation', 'sender', 'body')
        }),
        ('Status', {
            'fields': ('is_read', 'read_at')
        }),
        ('Timestamps', {
            'fields': ('timestamp',)
        }),
    )

    def body_preview(self, obj):
        """Display message body preview."""
        max_length = 50
        if len(obj.body) > max_length:
            return obj.body[:max_length] + '...'
        return obj.body
    body_preview.short_description = 'Message'

    def is_read_badge(self, obj):
        """Display read status with badge."""
        if obj.is_read:
            return format_html(
                '<span style="background-color: #28A745; color: white; padding: 3px 10px; border-radius: 3px;">READ</span>'
            )
        return format_html(
            '<span style="background-color: #FFA500; color: white; padding: 3px 10px; border-radius: 3px;">UNREAD</span>'
        )
    is_read_badge.short_description = 'Status'
