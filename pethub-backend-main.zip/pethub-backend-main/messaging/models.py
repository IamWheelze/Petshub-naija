"""
Models for real-time messaging between buyers and vendors.
"""

from django.db import models
from django.utils.translation import gettext_lazy as _
from django.conf import settings


class Conversation(models.Model):
    """
    Conversation between a buyer and a vendor regarding a listing.
    """
    buyer = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name='buyer_conversations',
        verbose_name=_('buyer')
    )
    vendor = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name='vendor_conversations',
        verbose_name=_('vendor')
    )
    listing = models.ForeignKey(
        'listings.PetListing',
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='conversations',
        verbose_name=_('listing'),
        help_text=_('Optional: The listing this conversation is about')
    )
    created_at = models.DateTimeField(_('created at'), auto_now_add=True)
    updated_at = models.DateTimeField(_('updated at'), auto_now=True)

    class Meta:
        verbose_name = _('conversation')
        verbose_name_plural = _('conversations')
        ordering = ['-updated_at']
        unique_together = [['buyer', 'vendor', 'listing']]
        indexes = [
            models.Index(fields=['buyer', '-updated_at']),
            models.Index(fields=['vendor', '-updated_at']),
        ]

    def __str__(self):
        if self.listing:
            return f"Conversation about {self.listing.title}"
        return f"Conversation between {self.buyer.email} and {self.vendor.email}"

    def get_unread_count(self, user):
        """Get the count of unread messages for a specific user."""
        return self.messages.filter(is_read=False).exclude(sender=user).count()

    def get_other_participant(self, user):
        """Get the other participant in the conversation."""
        return self.vendor if user == self.buyer else self.buyer


class Message(models.Model):
    """
    Individual message within a conversation.
    """
    conversation = models.ForeignKey(
        Conversation,
        on_delete=models.CASCADE,
        related_name='messages',
        verbose_name=_('conversation')
    )
    sender = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name='sent_messages',
        verbose_name=_('sender')
    )
    body = models.TextField(_('message body'))
    is_read = models.BooleanField(_('is read'), default=False)
    read_at = models.DateTimeField(_('read at'), null=True, blank=True)
    timestamp = models.DateTimeField(_('timestamp'), auto_now_add=True)

    class Meta:
        verbose_name = _('message')
        verbose_name_plural = _('messages')
        ordering = ['timestamp']
        indexes = [
            models.Index(fields=['conversation', 'timestamp']),
            models.Index(fields=['conversation', 'is_read']),
        ]

    def __str__(self):
        return f"Message from {self.sender.email} at {self.timestamp}"

    def mark_as_read(self):
        """Mark this message as read."""
        if not self.is_read:
            self.is_read = True
            self.read_at = models.functions.Now()
            self.save(update_fields=['is_read', 'read_at'])
