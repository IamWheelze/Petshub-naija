"""
URL configuration for the orders app.
"""

from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import OrderViewSet, ReviewViewSet, PaystackWebhookView, payment_callback

app_name = 'orders'

router = DefaultRouter()
router.register(r'orders', OrderViewSet, basename='order')
router.register(r'reviews', ReviewViewSet, basename='review')

urlpatterns = [
    path('webhook/', PaystackWebhookView.as_view(), name='paystack-webhook'),
    path('payment-callback/', payment_callback, name='payment-callback'),
    path('', include(router.urls)),
]
