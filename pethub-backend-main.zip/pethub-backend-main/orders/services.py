"""
Payment integration services for the orders app.
"""

import requests
import hashlib
import hmac
from decimal import Decimal
from django.conf import settings
from typing import Dict, Any, Optional


class PaystackService:
    """
    Service class for Paystack payment integration.
    """

    def __init__(self):
        self.secret_key = settings.PAYSTACK_SECRET_KEY
        self.public_key = settings.PAYSTACK_PUBLIC_KEY
        self.base_url = "https://api.paystack.co"
        self.headers = {
            "Authorization": f"Bearer {self.secret_key}",
            "Content-Type": "application/json",
        }

    def initialize_transaction(
        self,
        email: str,
        amount: Decimal,
        reference: str,
        callback_url: Optional[str] = None,
        metadata: Optional[Dict] = None
    ) -> Dict[str, Any]:
        """
        Initialize a payment transaction.

        Args:
            email: Customer's email address
            amount: Amount in Naira (will be converted to kobo)
            reference: Unique transaction reference
            callback_url: URL to redirect after payment
            metadata: Additional metadata to attach to transaction

        Returns:
            Dict containing transaction details including authorization_url

        Raises:
            requests.exceptions.RequestException: If API request fails
        """
        url = f"{self.base_url}/transaction/initialize"

        # Convert amount to kobo (Paystack uses kobo)
        amount_in_kobo = int(amount * 100)

        payload = {
            "email": email,
            "amount": amount_in_kobo,
            "reference": reference,
        }

        if callback_url:
            payload["callback_url"] = callback_url

        if metadata:
            payload["metadata"] = metadata

        try:
            response = requests.post(url, json=payload, headers=self.headers, timeout=30)
            response.raise_for_status()
            data = response.json()

            if data.get("status"):
                return {
                    "success": True,
                    "authorization_url": data["data"]["authorization_url"],
                    "access_code": data["data"]["access_code"],
                    "reference": data["data"]["reference"],
                }
            else:
                return {
                    "success": False,
                    "message": data.get("message", "Transaction initialization failed"),
                }

        except requests.exceptions.RequestException as e:
            return {
                "success": False,
                "message": f"Payment initialization failed: {str(e)}",
            }

    def verify_transaction(self, reference: str) -> Dict[str, Any]:
        """
        Verify a transaction.

        Args:
            reference: Transaction reference to verify

        Returns:
            Dict containing verification details

        Raises:
            requests.exceptions.RequestException: If API request fails
        """
        url = f"{self.base_url}/transaction/verify/{reference}"

        try:
            response = requests.get(url, headers=self.headers, timeout=30)
            response.raise_for_status()
            data = response.json()

            if data.get("status") and data.get("data"):
                transaction_data = data["data"]
                return {
                    "success": True,
                    "status": transaction_data["status"],
                    "reference": transaction_data["reference"],
                    "amount": Decimal(transaction_data["amount"]) / 100,  # Convert from kobo
                    "currency": transaction_data["currency"],
                    "paid_at": transaction_data.get("paid_at"),
                    "channel": transaction_data.get("channel"),
                }
            else:
                return {
                    "success": False,
                    "message": data.get("message", "Transaction verification failed"),
                }

        except requests.exceptions.RequestException as e:
            return {
                "success": False,
                "message": f"Payment verification failed: {str(e)}",
            }

    def validate_webhook(self, payload: bytes, signature: str) -> bool:
        """
        Validate Paystack webhook signature.

        Args:
            payload: Raw request body as bytes
            signature: X-Paystack-Signature header value

        Returns:
            True if signature is valid, False otherwise
        """
        try:
            # Compute HMAC signature
            computed_signature = hmac.new(
                self.secret_key.encode('utf-8'),
                payload,
                hashlib.sha512
            ).hexdigest()

            # Compare signatures
            return hmac.compare_digest(computed_signature, signature)

        except Exception:
            return False

    def refund_transaction(self, reference: str, amount: Optional[Decimal] = None) -> Dict[str, Any]:
        """
        Refund a transaction (full or partial).

        Args:
            reference: Transaction reference to refund
            amount: Amount to refund (optional, defaults to full refund)

        Returns:
            Dict containing refund status

        Raises:
            requests.exceptions.RequestException: If API request fails
        """
        url = f"{self.base_url}/refund"

        payload = {
            "transaction": reference,
        }

        if amount:
            payload["amount"] = int(amount * 100)  # Convert to kobo

        try:
            response = requests.post(url, json=payload, headers=self.headers, timeout=30)
            response.raise_for_status()
            data = response.json()

            if data.get("status"):
                return {
                    "success": True,
                    "message": "Refund initiated successfully",
                    "refund_data": data["data"],
                }
            else:
                return {
                    "success": False,
                    "message": data.get("message", "Refund failed"),
                }

        except requests.exceptions.RequestException as e:
            return {
                "success": False,
                "message": f"Refund failed: {str(e)}",
            }

    def get_transaction(self, transaction_id: int) -> Dict[str, Any]:
        """
        Get transaction details by ID.

        Args:
            transaction_id: Paystack transaction ID

        Returns:
            Dict containing transaction details

        Raises:
            requests.exceptions.RequestException: If API request fails
        """
        url = f"{self.base_url}/transaction/{transaction_id}"

        try:
            response = requests.get(url, headers=self.headers, timeout=30)
            response.raise_for_status()
            data = response.json()

            if data.get("status"):
                return {
                    "success": True,
                    "transaction": data["data"],
                }
            else:
                return {
                    "success": False,
                    "message": data.get("message", "Failed to fetch transaction"),
                }

        except requests.exceptions.RequestException as e:
            return {
                "success": False,
                "message": f"Failed to fetch transaction: {str(e)}",
            }
