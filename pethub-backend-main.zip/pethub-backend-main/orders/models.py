"""
Models for order and payment management.
"""

from django.db import models
from django.utils.translation import gettext_lazy as _
from django.conf import settings
from django.core.validators import MinValueValidator
import uuid


class Order(models.Model):
    """
    Order for a pet listing purchase.
    """

    class OrderStatus(models.TextChoices):
        PENDING = 'pending', _('Pending')
        PAID = 'paid', _('Paid')
        COMPLETED = 'completed', _('Completed')
        CANCELLED = 'cancelled', _('Cancelled')

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    buyer = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.PROTECT,
        related_name='purchases',
        verbose_name=_('buyer')
    )
    vendor = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.PROTECT,
        related_name='sales',
        verbose_name=_('vendor')
    )
    listing = models.ForeignKey(
        'listings.PetListing',
        on_delete=models.PROTECT,
        related_name='orders',
        verbose_name=_('listing')
    )
    total_price = models.DecimalField(
        _('total price'),
        max_digits=10,
        decimal_places=2,
        validators=[MinValueValidator(0)]
    )
    status = models.CharField(
        _('status'),
        max_length=15,
        choices=OrderStatus.choices,
        default=OrderStatus.PENDING,
    )
    payment_reference = models.CharField(
        _('payment reference'),
        max_length=255,
        unique=True,
        help_text=_('Paystack payment reference')
    )
    payment_verified_at = models.DateTimeField(_('payment verified at'), null=True, blank=True)
    notes = models.TextField(_('notes'), blank=True)
    created_at = models.DateTimeField(_('created at'), auto_now_add=True)
    updated_at = models.DateTimeField(_('updated at'), auto_now=True)

    class Meta:
        verbose_name = _('order')
        verbose_name_plural = _('orders')
        ordering = ['-created_at']
        indexes = [
            models.Index(fields=['buyer', '-created_at']),
            models.Index(fields=['vendor', '-created_at']),
            models.Index(fields=['status', '-created_at']),
            models.Index(fields=['payment_reference']),
        ]

    def __str__(self):
        return f"Order {self.id} - {self.listing.title}"

    @property
    def is_paid(self):
        """Check if order is paid."""
        return self.status in [self.OrderStatus.PAID, self.OrderStatus.COMPLETED]

    @property
    def is_pending(self):
        """Check if order is pending payment."""
        return self.status == self.OrderStatus.PENDING

    @property
    def is_completed(self):
        """Check if order is completed."""
        return self.status == self.OrderStatus.COMPLETED

    def mark_as_paid(self):
        """Mark order as paid."""
        if self.status == self.OrderStatus.PENDING:
            self.status = self.OrderStatus.PAID
            from django.utils import timezone
            self.payment_verified_at = timezone.now()
            self.save(update_fields=['status', 'payment_verified_at', 'updated_at'])

            # Mark the listing as sold
            self.listing.is_sold = True
            self.listing.is_active = False
            self.listing.save(update_fields=['is_sold', 'is_active'])

    def mark_as_completed(self):
        """Mark order as completed."""
        if self.is_paid:
            self.status = self.OrderStatus.COMPLETED
            self.save(update_fields=['status', 'updated_at'])

    def cancel(self):
        """Cancel the order."""
        if self.status == self.OrderStatus.PENDING:
            self.status = self.OrderStatus.CANCELLED
            self.save(update_fields=['status', 'updated_at'])


class Review(models.Model):
    """
    Review for a completed order (buyer reviews vendor).
    """
    order = models.OneToOneField(
        Order,
        on_delete=models.CASCADE,
        primary_key=True,
        related_name='review',
        verbose_name=_('order')
    )
    rating = models.PositiveSmallIntegerField(
        _('rating'),
        validators=[MinValueValidator(1)],
        help_text=_('Rating from 1 to 5')
    )
    comment = models.TextField(_('comment'), blank=True)
    created_at = models.DateTimeField(_('created at'), auto_now_add=True)

    class Meta:
        verbose_name = _('review')
        verbose_name_plural = _('reviews')
        ordering = ['-created_at']

    def __str__(self):
        return f"Review for Order {self.order.id} - {self.rating}/5"
