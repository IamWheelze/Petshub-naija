"""
Admin configuration for the orders app.
"""

from django.contrib import admin
from django.utils.html import format_html
from .models import Order, Review


@admin.register(Order)
class OrderAdmin(admin.ModelAdmin):
    """
    Admin for Order model.
    """
    list_display = [
        'id',
        'buyer',
        'vendor',
        'listing',
        'total_price',
        'status_badge',
        'payment_reference',
        'created_at',
    ]
    list_filter = ['status', 'created_at', 'payment_verified_at']
    search_fields = [
        'id',
        'payment_reference',
        'buyer__email',
        'vendor__email',
        'listing__title',
    ]
    readonly_fields = ['id', 'payment_reference', 'payment_verified_at', 'created_at', 'updated_at']
    ordering = ['-created_at']

    fieldsets = (
        ('Order Information', {
            'fields': ('id', 'buyer', 'vendor', 'listing', 'total_price')
        }),
        ('Payment', {
            'fields': ('payment_reference', 'status', 'payment_verified_at')
        }),
        ('Timeline', {
            'fields': ('created_at', 'updated_at')
        }),
    )

    def status_badge(self, obj):
        """Display order status with color badge."""
        colors = {
            'pending': '#FFA500',  # Orange
            'paid': '#007BFF',     # Blue
            'completed': '#28A745', # Green
            'cancelled': '#DC3545', # Red
        }
        color = colors.get(obj.status, '#6C757D')
        return format_html(
            '<span style="background-color: {}; color: white; padding: 3px 10px; border-radius: 3px;">{}</span>',
            color,
            obj.get_status_display().upper()
        )
    status_badge.short_description = 'Status'

    def has_add_permission(self, request):
        """Disable manual order creation via admin."""
        return False


@admin.register(Review)
class ReviewAdmin(admin.ModelAdmin):
    """
    Admin for Review model.
    """
    list_display = [
        'order',
        'buyer_name',
        'vendor_name',
        'rating_stars',
        'comment_preview',
        'created_at',
    ]
    list_filter = ['rating', 'created_at']
    search_fields = [
        'order__id',
        'order__buyer__email',
        'order__vendor__email',
        'comment',
    ]
    readonly_fields = ['order', 'created_at']
    ordering = ['-created_at']

    fieldsets = (
        ('Order Information', {
            'fields': ('order',)
        }),
        ('Review', {
            'fields': ('rating', 'comment')
        }),
        ('Timestamp', {
            'fields': ('created_at',)
        }),
    )

    def buyer_name(self, obj):
        """Get buyer name."""
        return obj.order.buyer.get_full_name()
    buyer_name.short_description = 'Buyer'

    def vendor_name(self, obj):
        """Get vendor name."""
        return obj.order.vendor.get_full_name()
    vendor_name.short_description = 'Vendor'

    def rating_stars(self, obj):
        """Display rating as stars."""
        stars = '★' * obj.rating + '☆' * (5 - obj.rating)
        return format_html(
            '<span style="color: #FFD700; font-size: 16px;">{}</span>',
            stars
        )
    rating_stars.short_description = 'Rating'

    def comment_preview(self, obj):
        """Display comment preview."""
        max_length = 50
        if obj.comment:
            if len(obj.comment) > max_length:
                return obj.comment[:max_length] + '...'
            return obj.comment
        return '-'
    comment_preview.short_description = 'Comment'

    def has_add_permission(self, request):
        """Disable manual review creation via admin."""
        return False
