"""
Views for the orders app.
"""

from rest_framework import viewsets, permissions, status
from rest_framework.decorators import action, api_view, permission_classes as drf_permission_classes
from rest_framework.response import Response
from rest_framework.views import APIView
from django.db.models import Q
from django.shortcuts import get_object_or_404
from django.views.decorators.csrf import csrf_exempt
from django.utils.decorators import method_decorator
from django.conf import settings
import json

from .models import Order, Review
from .serializers import (
    OrderSerializer,
    OrderCreateSerializer,
    ReviewSerializer,
    ReviewCreateSerializer,
)
from .services import PaystackService


class OrderViewSet(viewsets.ModelViewSet):
    """
    ViewSet for orders.

    List: GET /api/orders/
    Create: POST /api/orders/
    Retrieve: GET /api/orders/{id}/
    """
    permission_classes = [permissions.IsAuthenticated]

    def get_queryset(self):
        """Get orders where user is buyer or vendor."""
        user = self.request.user
        return Order.objects.filter(
            Q(buyer=user) | Q(vendor=user)
        ).select_related('buyer', 'vendor', 'listing').order_by('-created_at')

    def get_serializer_class(self):
        """Use different serializers for create vs other actions."""
        if self.action == 'create':
            return OrderCreateSerializer
        return OrderSerializer

    def create(self, request, *args, **kwargs):
        """
        Create order and initialize payment.

        POST /api/orders/
        {
            "listing_id": 1
        }
        """
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        order = serializer.save()

        # Initialize payment with Paystack
        paystack = PaystackService()
        callback_url = request.build_absolute_uri('/api/orders/payment-callback/')

        payment_result = paystack.initialize_transaction(
            email=request.user.email,
            amount=order.total_price,
            reference=order.payment_reference,
            callback_url=callback_url,
            metadata={
                "order_id": str(order.id),
                "buyer_name": request.user.get_full_name(),
                "listing_title": order.listing.title,
            }
        )

        if payment_result.get("success"):
            return Response(
                {
                    "message": "Order created successfully. Please proceed to payment.",
                    "order": OrderSerializer(order).data,
                    "payment_url": payment_result["authorization_url"],
                },
                status=status.HTTP_201_CREATED
            )
        else:
            # Delete order if payment initialization fails
            order.delete()
            return Response(
                {
                    "error": "Failed to initialize payment.",
                    "details": payment_result.get("message"),
                },
                status=status.HTTP_400_BAD_REQUEST
            )

    @action(detail=True, methods=['post'])
    def verify_payment(self, request, pk=None):
        """
        Verify payment for an order.

        POST /api/orders/{id}/verify_payment/
        """
        order = self.get_object()

        # Verify user is the buyer
        if order.buyer != request.user:
            return Response(
                {"error": "You can only verify your own orders."},
                status=status.HTTP_403_FORBIDDEN
            )

        # Check if already paid
        if order.status == Order.OrderStatus.PAID:
            return Response(
                {"message": "Order is already paid."},
                status=status.HTTP_200_OK
            )

        # Verify with Paystack
        paystack = PaystackService()
        verification_result = paystack.verify_transaction(order.payment_reference)

        if verification_result.get("success") and verification_result.get("status") == "success":
            # Mark order as paid
            order.mark_as_paid()

            return Response(
                {
                    "message": "Payment verified successfully.",
                    "order": OrderSerializer(order).data,
                },
                status=status.HTTP_200_OK
            )
        else:
            return Response(
                {
                    "error": "Payment verification failed.",
                    "details": verification_result.get("message"),
                },
                status=status.HTTP_400_BAD_REQUEST
            )

    @action(detail=True, methods=['post'])
    def mark_as_completed(self, request, pk=None):
        """
        Mark order as completed (vendor only).

        POST /api/orders/{id}/mark_as_completed/
        """
        order = self.get_object()

        # Verify user is the vendor
        if order.vendor != request.user:
            return Response(
                {"error": "Only the vendor can mark the order as completed."},
                status=status.HTTP_403_FORBIDDEN
            )

        # Check if order is paid
        if order.status != Order.OrderStatus.PAID:
            return Response(
                {"error": "Order must be paid before it can be completed."},
                status=status.HTTP_400_BAD_REQUEST
            )

        # Mark as completed
        order.mark_as_completed()

        return Response(
            {
                "message": "Order marked as completed.",
                "order": OrderSerializer(order).data,
            },
            status=status.HTTP_200_OK
        )

    @action(detail=True, methods=['post'])
    def cancel(self, request, pk=None):
        """
        Cancel an order (buyer only, before payment).

        POST /api/orders/{id}/cancel/
        """
        order = self.get_object()

        # Verify user is the buyer
        if order.buyer != request.user:
            return Response(
                {"error": "You can only cancel your own orders."},
                status=status.HTTP_403_FORBIDDEN
            )

        # Can only cancel pending orders
        if order.status != Order.OrderStatus.PENDING:
            return Response(
                {"error": "Only pending orders can be cancelled."},
                status=status.HTTP_400_BAD_REQUEST
            )

        order.status = Order.OrderStatus.CANCELLED
        order.save(update_fields=['status'])

        return Response(
            {"message": "Order cancelled successfully."},
            status=status.HTTP_200_OK
        )


@method_decorator(csrf_exempt, name='dispatch')
class PaystackWebhookView(APIView):
    """
    Handle Paystack webhook events.

    POST /api/orders/webhook/
    """
    permission_classes = []  # No authentication required for webhooks

    def post(self, request):
        """
        Handle webhook event from Paystack.
        """
        # Get signature from header
        signature = request.headers.get('X-Paystack-Signature')

        if not signature:
            return Response(
                {"error": "Missing signature"},
                status=status.HTTP_400_BAD_REQUEST
            )

        # Validate webhook signature
        paystack = PaystackService()
        payload = request.body

        if not paystack.validate_webhook(payload, signature):
            return Response(
                {"error": "Invalid signature"},
                status=status.HTTP_400_BAD_REQUEST
            )

        # Parse event data
        try:
            event_data = json.loads(payload)
            event_type = event_data.get('event')

            if event_type == 'charge.success':
                # Handle successful payment
                data = event_data.get('data', {})
                reference = data.get('reference')

                if reference:
                    try:
                        order = Order.objects.get(payment_reference=reference)

                        if order.status == Order.OrderStatus.PENDING:
                            order.mark_as_paid()

                            # TODO: Send email notification via Celery
                            # send_payment_confirmation_email.delay(order.id)

                    except Order.DoesNotExist:
                        pass  # Order not found, ignore

            return Response({"status": "success"}, status=status.HTTP_200_OK)

        except json.JSONDecodeError:
            return Response(
                {"error": "Invalid JSON"},
                status=status.HTTP_400_BAD_REQUEST
            )


class ReviewViewSet(viewsets.ModelViewSet):
    """
    ViewSet for reviews.

    List: GET /api/orders/reviews/
    Create: POST /api/orders/reviews/
    Retrieve: GET /api/orders/reviews/{id}/
    Update: PUT/PATCH /api/orders/reviews/{id}/ (owner only)
    Delete: DELETE /api/orders/reviews/{id}/ (owner only)
    """
    serializer_class = ReviewSerializer
    permission_classes = [permissions.IsAuthenticatedOrReadOnly]

    def get_queryset(self):
        """Get all reviews or filter by vendor/listing."""
        queryset = Review.objects.select_related(
            'order__buyer',
            'order__vendor',
            'order__listing'
        ).all()

        # Filter by vendor
        vendor_id = self.request.query_params.get('vendor_id')
        if vendor_id:
            queryset = queryset.filter(order__vendor_id=vendor_id)

        # Filter by listing
        listing_id = self.request.query_params.get('listing_id')
        if listing_id:
            queryset = queryset.filter(order__listing_id=listing_id)

        return queryset.order_by('-created_at')

    def get_serializer_class(self):
        """Use different serializers for create vs other actions."""
        if self.action == 'create':
            return ReviewCreateSerializer
        return ReviewSerializer

    def get_permissions(self):
        """Set permissions based on action."""
        if self.action in ['update', 'partial_update', 'destroy']:
            return [permissions.IsAuthenticated()]
        return [permissions.IsAuthenticatedOrReadOnly()]

    def perform_update(self, serializer):
        """Only allow buyer to update their own review."""
        review = self.get_object()
        if review.order.buyer != self.request.user:
            raise permissions.PermissionDenied("You can only update your own reviews.")
        serializer.save()

    def perform_destroy(self, instance):
        """Only allow buyer to delete their own review."""
        if instance.order.buyer != self.request.user:
            raise permissions.PermissionDenied("You can only delete your own reviews.")
        instance.delete()


@api_view(['GET'])
@drf_permission_classes([permissions.AllowAny])
def payment_callback(request):
    """
    Payment callback endpoint for Paystack redirect.

    GET /api/orders/payment-callback/?reference=<reference>
    """
    reference = request.query_params.get('reference')

    if not reference:
        return Response(
            {"error": "Missing payment reference"},
            status=status.HTTP_400_BAD_REQUEST
        )

    # Verify payment
    paystack = PaystackService()
    verification_result = paystack.verify_transaction(reference)

    if verification_result.get("success") and verification_result.get("status") == "success":
        try:
            order = Order.objects.get(payment_reference=reference)

            if order.status == Order.OrderStatus.PENDING:
                order.mark_as_paid()

            return Response(
                {
                    "message": "Payment successful!",
                    "order_id": str(order.id),
                    "status": order.status,
                },
                status=status.HTTP_200_OK
            )

        except Order.DoesNotExist:
            return Response(
                {"error": "Order not found"},
                status=status.HTTP_404_NOT_FOUND
            )
    else:
        return Response(
            {
                "error": "Payment verification failed",
                "details": verification_result.get("message"),
            },
            status=status.HTTP_400_BAD_REQUEST
        )
