"""
Serializers for the orders app.
"""

from rest_framework import serializers
from django.core.validators import MinValueValidator, MaxValueValidator
from .models import Order, Review
from listings.models import PetListing


class OrderSerializer(serializers.ModelSerializer):
    """
    Serializer for orders.
    """
    buyer_name = serializers.CharField(source='buyer.get_full_name', read_only=True)
    vendor_name = serializers.CharField(source='vendor.get_full_name', read_only=True)
    listing_title = serializers.CharField(source='listing.title', read_only=True)
    status_display = serializers.CharField(source='get_status_display', read_only=True)

    class Meta:
        model = Order
        fields = [
            'id',
            'buyer',
            'buyer_name',
            'vendor',
            'vendor_name',
            'listing',
            'listing_title',
            'total_price',
            'status',
            'status_display',
            'payment_reference',
            'payment_verified_at',
            'completed_at',
            'created_at',
            'updated_at',
        ]
        read_only_fields = [
            'id',
            'buyer',
            'vendor',
            'payment_verified_at',
            'completed_at',
            'created_at',
            'updated_at',
        ]


class OrderCreateSerializer(serializers.ModelSerializer):
    """
    Serializer for creating orders.
    """
    listing_id = serializers.IntegerField(write_only=True)

    class Meta:
        model = Order
        fields = ['listing_id']

    def validate_listing_id(self, value):
        """Validate that listing exists and is available."""
        try:
            listing = PetListing.objects.get(pk=value)

            if not listing.is_active:
                raise serializers.ValidationError("This listing is not active.")

            if listing.is_sold:
                raise serializers.ValidationError("This listing has already been sold.")

            return value
        except PetListing.DoesNotExist:
            raise serializers.ValidationError("Listing not found.")

    def validate(self, attrs):
        """Additional validation."""
        request = self.context.get('request')
        listing = PetListing.objects.get(pk=attrs['listing_id'])

        # Prevent vendor from buying their own listing
        if listing.vendor == request.user:
            raise serializers.ValidationError("You cannot purchase your own listing.")

        # Check if buyer already has a pending order for this listing
        existing_order = Order.objects.filter(
            buyer=request.user,
            listing=listing,
            status=Order.OrderStatus.PENDING
        ).exists()

        if existing_order:
            raise serializers.ValidationError("You already have a pending order for this listing.")

        return attrs

    def create(self, validated_data):
        """Create order with payment reference."""
        import secrets

        request = self.context.get('request')
        listing = PetListing.objects.get(pk=validated_data['listing_id'])

        # Generate payment reference
        payment_reference = f"PETHUB-{secrets.token_urlsafe(16).upper()}"

        order = Order.objects.create(
            buyer=request.user,
            vendor=listing.vendor,
            listing=listing,
            total_price=listing.price,
            payment_reference=payment_reference,
        )

        return order


class ReviewSerializer(serializers.ModelSerializer):
    """
    Serializer for reviews.
    """
    buyer_name = serializers.CharField(source='order.buyer.get_full_name', read_only=True)
    listing_title = serializers.CharField(source='order.listing.title', read_only=True)

    class Meta:
        model = Review
        fields = [
            'order',
            'buyer_name',
            'listing_title',
            'rating',
            'comment',
            'created_at',
        ]
        read_only_fields = ['order', 'created_at']

    def validate_rating(self, value):
        """Validate rating is between 1 and 5."""
        if value < 1 or value > 5:
            raise serializers.ValidationError("Rating must be between 1 and 5.")
        return value


class ReviewCreateSerializer(serializers.ModelSerializer):
    """
    Serializer for creating reviews.
    """
    order_id = serializers.UUIDField(write_only=True)

    class Meta:
        model = Review
        fields = ['order_id', 'rating', 'comment']

    def validate_order_id(self, value):
        """Validate that order exists and is completed."""
        try:
            order = Order.objects.get(pk=value)

            if order.status != Order.OrderStatus.COMPLETED:
                raise serializers.ValidationError("You can only review completed orders.")

            return value
        except Order.DoesNotExist:
            raise serializers.ValidationError("Order not found.")

    def validate(self, attrs):
        """Additional validation."""
        request = self.context.get('request')
        order = Order.objects.get(pk=attrs['order_id'])

        # Only buyer can review
        if order.buyer != request.user:
            raise serializers.ValidationError("You can only review your own orders.")

        # Check if review already exists
        if hasattr(order, 'review'):
            raise serializers.ValidationError("You have already reviewed this order.")

        return attrs

    def create(self, validated_data):
        """Create review for order."""
        order_id = validated_data.pop('order_id')
        order = Order.objects.get(pk=order_id)

        review = Review.objects.create(
            order=order,
            **validated_data
        )

        return review
