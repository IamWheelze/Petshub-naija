"""
Views for the accounts app.
"""

from rest_framework import generics, status, permissions
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework_simplejwt.views import TokenObtainPairView
from django.contrib.auth import get_user_model
from django.shortcuts import get_object_or_404
from django.utils import timezone

from .serializers import (
    UserRegistrationSerializer,
    UserSerializer,
    EmailVerificationSerializer,
    PasswordResetRequestSerializer,
    PasswordResetConfirmSerializer,
    VendorProfileSerializer,
    VendorProfilePublicSerializer,
)
from .models import VendorProfile
from .permissions import IsVendor, IsVerifiedVendor

User = get_user_model()


class UserRegistrationView(generics.CreateAPIView):
    """
    Register a new user account.

    POST /api/accounts/register/
    {
        "email": "user@example.com",
        "password": "SecurePass123!",
        "confirm_password": "SecurePass123!",
        "first_name": "John",
        "last_name": "Doe",
        "phone_number": "+2348012345678",
        "role": "buyer"  # or "vendor"
    }
    """
    serializer_class = UserRegistrationSerializer
    permission_classes = [permissions.AllowAny]

    def create(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        user = serializer.save()

        # TODO: Send verification email via Celery task
        # send_verification_email.delay(user.id)

        return Response(
            {
                "message": "Registration successful. Please check your email to verify your account.",
                "email": user.email,
                "verification_token": user.verification_token,  # Remove in production
            },
            status=status.HTTP_201_CREATED,
        )


class EmailVerificationView(APIView):
    """
    Verify user email with token.

    POST /api/accounts/verify-email/
    {
        "email": "user@example.com",
        "token": "verification_token_here"
    }
    """
    permission_classes = [permissions.AllowAny]

    def post(self, request):
        serializer = EmailVerificationSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)

        email = serializer.validated_data["email"]
        token = serializer.validated_data["token"]

        try:
            user = User.objects.get(email=email, verification_token=token)

            if user.email_verified:
                return Response(
                    {"message": "Email already verified."},
                    status=status.HTTP_200_OK,
                )

            user.email_verified = True
            user.is_active = True
            user.verification_token = ""
            user.save(update_fields=["email_verified", "is_active", "verification_token"])

            return Response(
                {"message": "Email verified successfully. You can now log in."},
                status=status.HTTP_200_OK,
            )

        except User.DoesNotExist:
            return Response(
                {"error": "Invalid verification token or email."},
                status=status.HTTP_400_BAD_REQUEST,
            )


class PasswordResetRequestView(APIView):
    """
    Request password reset token.

    POST /api/accounts/password-reset/
    {
        "email": "user@example.com"
    }
    """
    permission_classes = [permissions.AllowAny]

    def post(self, request):
        serializer = PasswordResetRequestSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)

        email = serializer.validated_data["email"]

        try:
            user = User.objects.get(email=email)
            token = user.generate_password_reset_token()

            # TODO: Send password reset email via Celery task
            # send_password_reset_email.delay(user.id, token)

            return Response(
                {
                    "message": "Password reset instructions sent to your email.",
                    "reset_token": token,  # Remove in production
                },
                status=status.HTTP_200_OK,
            )

        except User.DoesNotExist:
            # Return success even if user doesn't exist (security best practice)
            return Response(
                {"message": "Password reset instructions sent to your email."},
                status=status.HTTP_200_OK,
            )


class PasswordResetConfirmView(APIView):
    """
    Confirm password reset with token and new password.

    POST /api/accounts/password-reset-confirm/
    {
        "email": "user@example.com",
        "token": "reset_token_here",
        "new_password": "NewSecurePass123!",
        "confirm_password": "NewSecurePass123!"
    }
    """
    permission_classes = [permissions.AllowAny]

    def post(self, request):
        serializer = PasswordResetConfirmSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)

        email = serializer.validated_data["email"]
        token = serializer.validated_data["token"]
        new_password = serializer.validated_data["new_password"]

        try:
            user = User.objects.get(email=email, password_reset_token=token)

            # Check if token is expired (24 hours)
            if user.password_reset_expires_at and user.password_reset_expires_at < timezone.now():
                return Response(
                    {"error": "Password reset token has expired. Please request a new one."},
                    status=status.HTTP_400_BAD_REQUEST,
                )

            user.set_password(new_password)
            user.password_reset_token = ""
            user.password_reset_expires_at = None
            user.save(update_fields=["password", "password_reset_token", "password_reset_expires_at"])

            return Response(
                {"message": "Password reset successful. You can now log in with your new password."},
                status=status.HTTP_200_OK,
            )

        except User.DoesNotExist:
            return Response(
                {"error": "Invalid reset token or email."},
                status=status.HTTP_400_BAD_REQUEST,
            )


class UserProfileView(generics.RetrieveUpdateAPIView):
    """
    Get or update current user's profile.

    GET /api/accounts/profile/
    PUT/PATCH /api/accounts/profile/
    """
    serializer_class = UserSerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_object(self):
        return self.request.user


class VendorProfileCreateView(generics.CreateAPIView):
    """
    Create a vendor profile (vendor users only).

    POST /api/accounts/vendor-profile/create/
    {
        "business_name": "Pet Store Ltd",
        "business_address": "123 Main St, Lagos",
        "business_phone": "+2348012345678",
        "cac_number": "RC1234567",
        "cac_document": <file upload>
    }
    """
    serializer_class = VendorProfileSerializer
    permission_classes = [permissions.IsAuthenticated, IsVendor]

    def perform_create(self, serializer):
        serializer.save(user=self.request.user)


class VendorProfileDetailView(generics.RetrieveUpdateAPIView):
    """
    Get or update a vendor profile.

    GET /api/accounts/vendor-profile/{id}/
    PUT/PATCH /api/accounts/vendor-profile/{id}/
    """
    queryset = VendorProfile.objects.select_related('user').all()
    permission_classes = [permissions.IsAuthenticated]

    def get_serializer_class(self):
        # Owner can see full details, others see public profile
        if self.request.user.id == self.get_object().user_id:
            return VendorProfileSerializer
        return VendorProfilePublicSerializer


class VendorProfileListView(generics.ListAPIView):
    """
    List all approved vendor profiles.

    GET /api/accounts/vendor-profiles/
    """
    serializer_class = VendorProfilePublicSerializer
    permission_classes = [permissions.AllowAny]

    def get_queryset(self):
        return VendorProfile.objects.filter(
            verification_status=VendorProfile.VerificationStatus.APPROVED
        ).select_related('user')
