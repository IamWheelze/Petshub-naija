"""
Admin configuration for the accounts app.
"""

from django.contrib import admin
from django.contrib.auth.admin import UserAdmin as BaseUserAdmin
from django.utils.html import format_html
from .models import User, VendorProfile


@admin.register(User)
class UserAdmin(BaseUserAdmin):
    """
    Custom admin for User model.
    """
    list_display = ['email', 'get_full_name', 'role', 'email_verified', 'is_active', 'date_joined']
    list_filter = ['role', 'email_verified', 'is_active', 'is_staff', 'date_joined']
    search_fields = ['email', 'first_name', 'last_name', 'phone_number']
    ordering = ['-date_joined']

    fieldsets = (
        (None, {'fields': ('email', 'password')}),
        ('Personal Info', {'fields': ('first_name', 'last_name', 'phone_number')}),
        ('Permissions', {'fields': ('role', 'email_verified', 'is_active', 'is_staff', 'is_superuser', 'groups', 'user_permissions')}),
        ('Important Dates', {'fields': ('last_login', 'date_joined')}),
    )

    add_fieldsets = (
        (None, {
            'classes': ('wide',),
            'fields': ('email', 'password1', 'password2', 'first_name', 'last_name', 'phone_number', 'role'),
        }),
    )

    def get_full_name(self, obj):
        return obj.get_full_name()
    get_full_name.short_description = 'Full Name'


@admin.register(VendorProfile)
class VendorProfileAdmin(admin.ModelAdmin):
    """
    Admin for VendorProfile model with vendor approval workflow.
    """
    list_display = [
        'user',
        'business_name',
        'verification_status_badge',
        'city',
        'created_at',
    ]
    list_filter = ['verification_status', 'state', 'created_at']
    search_fields = ['business_name', 'user__email', 'user__first_name', 'user__last_name']
    readonly_fields = ['created_at', 'updated_at']
    ordering = ['-created_at']

    fieldsets = (
        ('User', {'fields': ('user',)}),
        ('Business Information', {
            'fields': ('business_name', 'address', 'city', 'state', 'bio')
        }),
        ('Verification', {
            'fields': ('verification_status', 'cac_document')
        }),
        ('Timestamps', {'fields': ('created_at', 'updated_at')}),
    )

    actions = ['approve_vendors', 'reject_vendors']

    def verification_status_badge(self, obj):
        """Display verification status with color badge."""
        colors = {
            'pending': '#FFA500',
            'approved': '#28A745',
            'rejected': '#DC3545',
        }
        color = colors.get(obj.verification_status, '#6C757D')
        return format_html(
            '<span style="background-color: {}; color: white; padding: 3px 10px; border-radius: 3px;">{}</span>',
            color,
            obj.get_verification_status_display()
        )
    verification_status_badge.short_description = 'Status'

    def approve_vendors(self, request, queryset):
        """Bulk approve vendor profiles."""
        updated = queryset.filter(
            verification_status=VendorProfile.VerificationStatus.PENDING
        ).update(verification_status=VendorProfile.VerificationStatus.APPROVED)

        self.message_user(request, f'{updated} vendor(s) approved successfully.')

        # TODO: Send approval email via Celery
        # for profile in queryset:
        #     send_vendor_status_email.delay(profile.user_id, 'approved')

    approve_vendors.short_description = 'Approve selected vendors'

    def reject_vendors(self, request, queryset):
        """Bulk reject vendor profiles."""
        updated = queryset.filter(
            verification_status=VendorProfile.VerificationStatus.PENDING
        ).update(verification_status=VendorProfile.VerificationStatus.REJECTED)

        self.message_user(request, f'{updated} vendor(s) rejected.')

        # TODO: Send rejection email via Celery
        # for profile in queryset:
        #     send_vendor_status_email.delay(profile.user_id, 'rejected')

    reject_vendors.short_description = 'Reject selected vendors'
