"""
Custom permissions for the accounts app.
"""

from rest_framework import permissions


class IsVendor(permissions.BasePermission):
    """
    Permission to only allow vendors to access a view.
    """
    message = "Only verified vendors can perform this action."

    def has_permission(self, request, view):
        return (
            request.user and
            request.user.is_authenticated and
            request.user.is_vendor
        )


class IsVerifiedVendor(permissions.BasePermission):
    """
    Permission to only allow verified vendors to access a view.
    """
    message = "Only verified vendors can perform this action. Please complete your vendor verification."

    def has_permission(self, request, view):
        return (
            request.user and
            request.user.is_authenticated and
            request.user.is_verified_vendor
        )


class IsOwnerOrReadOnly(permissions.BasePermission):
    """
    Permission to allow owners to edit/delete objects, but allow read for everyone.
    """

    def has_object_permission(self, request, view, obj):
        # Read permissions are allowed for any request
        if request.method in permissions.SAFE_METHODS:
            return True

        # Write permissions are only allowed to the owner
        # Check if the object has a 'vendor' or 'user' attribute
        if hasattr(obj, 'vendor'):
            return obj.vendor == request.user
        elif hasattr(obj, 'user'):
            return obj.user == request.user
        return False


class IsBuyer(permissions.BasePermission):
    """
    Permission to only allow buyers to access a view.
    """
    message = "Only buyers can perform this action."

    def has_permission(self, request, view):
        return (
            request.user and
            request.user.is_authenticated and
            request.user.is_buyer
        )
