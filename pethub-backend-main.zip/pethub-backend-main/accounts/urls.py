"""
URL configuration for the accounts app.
"""

from django.urls import path
from .views import (
    UserRegistrationView,
    EmailVerificationView,
    PasswordResetRequestView,
    PasswordResetConfirmView,
    UserProfileView,
    VendorProfileCreateView,
    VendorProfileDetailView,
    VendorProfileListView,
)

app_name = 'accounts'

urlpatterns = [
    # Authentication
    path('register/', UserRegistrationView.as_view(), name='register'),
    path('verify-email/', EmailVerificationView.as_view(), name='verify-email'),
    path('password-reset/', PasswordResetRequestView.as_view(), name='password-reset'),
    path('password-reset-confirm/', PasswordResetConfirmView.as_view(), name='password-reset-confirm'),

    # User Profile
    path('profile/', UserProfileView.as_view(), name='user-profile'),

    # Vendor Profiles
    path('vendor-profile/create/', VendorProfileCreateView.as_view(), name='vendor-profile-create'),
    path('vendor-profile/<int:pk>/', VendorProfileDetailView.as_view(), name='vendor-profile-detail'),
    path('vendor-profiles/', VendorProfileListView.as_view(), name='vendor-profile-list'),
]
