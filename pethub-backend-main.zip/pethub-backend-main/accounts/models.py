"""
User and Vendor Profile models for the accounts app.
"""

from django.contrib.auth.models import AbstractUser, BaseUserManager
from django.db import models
from django.utils.translation import gettext_lazy as _
import secrets


class UserManager(BaseUserManager):
    """Custom user manager for email-based authentication."""

    def create_user(self, email, password=None, **extra_fields):
        """Create and save a regular user with the given email and password."""
        if not email:
            raise ValueError(_('The Email field must be set'))
        email = self.normalize_email(email)
        user = self.model(email=email, **extra_fields)
        user.set_password(password)
        user.save(using=self._db)
        return user

    def create_superuser(self, email, password=None, **extra_fields):
        """Create and save a superuser with the given email and password."""
        extra_fields.setdefault('is_staff', True)
        extra_fields.setdefault('is_superuser', True)
        extra_fields.setdefault('is_active', True)

        if extra_fields.get('is_staff') is not True:
            raise ValueError(_('Superuser must have is_staff=True.'))
        if extra_fields.get('is_superuser') is not True:
            raise ValueError(_('Superuser must have is_superuser=True.'))

        return self.create_user(email, password, **extra_fields)


class User(AbstractUser):
    """
    Custom User model with role-based authentication.

    Roles:
    - Buyer: Can browse listings, make purchases, and communicate with vendors
    - Vendor: Can create listings, manage inventory, and sell pets (requires verification)
    """

    class Role(models.TextChoices):
        BUYER = 'buyer', _('Buyer')
        VENDOR = 'vendor', _('Vendor')

    username = None  # Remove username field
    email = models.EmailField(_('email address'), unique=True)
    phone_number = models.CharField(_('phone number'), max_length=20, unique=True)
    role = models.CharField(
        _('role'),
        max_length=10,
        choices=Role.choices,
        default=Role.BUYER,
    )
    email_verified = models.BooleanField(_('email verified'), default=False)
    phone_verified = models.BooleanField(_('phone verified'), default=False)
    verification_token = models.CharField(_('verification token'), max_length=100, blank=True)
    password_reset_token = models.CharField(_('password reset token'), max_length=100, blank=True)
    created_at = models.DateTimeField(_('created at'), auto_now_add=True)
    updated_at = models.DateTimeField(_('updated at'), auto_now=True)

    objects = UserManager()

    USERNAME_FIELD = 'email'
    REQUIRED_FIELDS = ['first_name', 'last_name', 'phone_number']

    class Meta:
        verbose_name = _('user')
        verbose_name_plural = _('users')
        ordering = ['-created_at']

    def __str__(self):
        return f"{self.email} ({self.get_role_display()})"

    def generate_verification_token(self):
        """Generate a unique verification token for email verification."""
        self.verification_token = secrets.token_urlsafe(32)
        self.save(update_fields=['verification_token'])
        return self.verification_token

    def generate_password_reset_token(self):
        """Generate a unique token for password reset."""
        self.password_reset_token = secrets.token_urlsafe(32)
        self.save(update_fields=['password_reset_token'])
        return self.password_reset_token

    def verify_email(self):
        """Mark the user's email as verified."""
        self.email_verified = True
        self.is_active = True
        self.verification_token = ''
        self.save(update_fields=['email_verified', 'is_active', 'verification_token'])

    @property
    def is_buyer(self):
        """Check if user has buyer role."""
        return self.role == self.Role.BUYER

    @property
    def is_vendor(self):
        """Check if user has vendor role."""
        return self.role == self.Role.VENDOR

    @property
    def is_verified_vendor(self):
        """Check if user is a verified vendor."""
        return (
            self.is_vendor and
            hasattr(self, 'vendor_profile') and
            self.vendor_profile.verification_status == VendorProfile.VerificationStatus.APPROVED
        )


class VendorProfile(models.Model):
    """
    Extended profile for Vendor users.

    Vendors must be manually verified by an admin before they can create listings.
    """

    class VerificationStatus(models.TextChoices):
        PENDING = 'pending', _('Pending')
        APPROVED = 'approved', _('Approved')
        REJECTED = 'rejected', _('Rejected')

    user = models.OneToOneField(
        User,
        on_delete=models.CASCADE,
        primary_key=True,
        related_name='vendor_profile'
    )
    business_name = models.CharField(_('business name'), max_length=255)
    address = models.TextField(_('address'))
    city = models.CharField(_('city'), max_length=100)
    state = models.CharField(_('state'), max_length=100)
    bio = models.TextField(_('bio'), help_text=_('Tell buyers about your business'))
    cac_document = models.FileField(
        _('CAC document'),
        upload_to='vendor_documents/',
        blank=True,
        null=True,
        help_text=_('Corporate Affairs Commission registration document (optional)')
    )
    verification_status = models.CharField(
        _('verification status'),
        max_length=10,
        choices=VerificationStatus.choices,
        default=VerificationStatus.PENDING,
    )
    verified_at = models.DateTimeField(_('verified at'), blank=True, null=True)
    rejection_reason = models.TextField(_('rejection reason'), blank=True)
    created_at = models.DateTimeField(_('created at'), auto_now_add=True)
    updated_at = models.DateTimeField(_('updated at'), auto_now=True)

    class Meta:
        verbose_name = _('vendor profile')
        verbose_name_plural = _('vendor profiles')
        ordering = ['-created_at']

    def __str__(self):
        return f"{self.business_name} ({self.get_verification_status_display()})"

    @property
    def is_approved(self):
        """Check if vendor is approved."""
        return self.verification_status == self.VerificationStatus.APPROVED

    @property
    def is_pending(self):
        """Check if vendor verification is pending."""
        return self.verification_status == self.VerificationStatus.PENDING

    @property
    def is_rejected(self):
        """Check if vendor was rejected."""
        return self.verification_status == self.VerificationStatus.REJECTED
