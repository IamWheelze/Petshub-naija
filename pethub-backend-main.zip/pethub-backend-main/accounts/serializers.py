"""
Serializers for user authentication and vendor profile management.
"""

from rest_framework import serializers
from django.contrib.auth.password_validation import validate_password
from django.core.exceptions import ValidationError as DjangoValidationError
from .models import User, VendorProfile


class UserSerializer(serializers.ModelSerializer):
    """Serializer for User model."""

    class Meta:
        model = User
        fields = [
            'id', 'email', 'first_name', 'last_name', 'phone_number',
            'role', 'email_verified', 'phone_verified', 'is_active',
            'created_at', 'updated_at'
        ]
        read_only_fields = ['id', 'email_verified', 'phone_verified', 'is_active', 'created_at', 'updated_at']


class UserRegistrationSerializer(serializers.ModelSerializer):
    """Serializer for user registration."""

    password = serializers.CharField(write_only=True, required=True, style={'input_type': 'password'})
    confirm_password = serializers.CharField(write_only=True, required=True, style={'input_type': 'password'})

    class Meta:
        model = User
        fields = [
            'email', 'phone_number', 'first_name', 'last_name',
            'password', 'confirm_password', 'role'
        ]

    def validate_email(self, value):
        """Validate that email is unique."""
        if User.objects.filter(email=value).exists():
            raise serializers.ValidationError("An account with this email already exists.")
        return value

    def validate_phone_number(self, value):
        """Validate that phone number is unique and in valid format."""
        if User.objects.filter(phone_number=value).exists():
            raise serializers.ValidationError("An account with this phone number already exists.")

        # Basic Nigerian phone number validation (can be improved)
        if not value.startswith(('+234', '0')) or len(value) < 11:
            raise serializers.ValidationError("Please enter a valid Nigerian phone number.")

        return value

    def validate(self, attrs):
        """Validate that passwords match and meet requirements."""
        if attrs['password'] != attrs.pop('confirm_password'):
            raise serializers.ValidationError({"confirm_password": "Passwords do not match."})

        # Validate password using Django's validators
        try:
            validate_password(attrs['password'])
        except DjangoValidationError as e:
            raise serializers.ValidationError({"password": list(e.messages)})

        return attrs

    def create(self, validated_data):
        """Create a new user with hashed password."""
        user = User.objects.create_user(
            email=validated_data['email'],
            password=validated_data['password'],
            first_name=validated_data['first_name'],
            last_name=validated_data['last_name'],
            phone_number=validated_data['phone_number'],
            role=validated_data.get('role', User.Role.BUYER),
            is_active=False  # Inactive until email is verified
        )
        # Generate verification token
        user.generate_verification_token()
        return user


class EmailVerificationSerializer(serializers.Serializer):
    """Serializer for email verification."""
    token = serializers.CharField(required=True)


class PasswordResetRequestSerializer(serializers.Serializer):
    """Serializer for password reset request."""
    email = serializers.EmailField(required=True)


class PasswordResetConfirmSerializer(serializers.Serializer):
    """Serializer for password reset confirmation."""
    token = serializers.CharField(required=True)
    password = serializers.CharField(write_only=True, required=True, style={'input_type': 'password'})
    confirm_password = serializers.CharField(write_only=True, required=True, style={'input_type': 'password'})

    def validate(self, attrs):
        """Validate that passwords match and meet requirements."""
        if attrs['password'] != attrs.pop('confirm_password'):
            raise serializers.ValidationError({"confirm_password": "Passwords do not match."})

        try:
            validate_password(attrs['password'])
        except DjangoValidationError as e:
            raise serializers.ValidationError({"password": list(e.messages)})

        return attrs


class VendorProfileSerializer(serializers.ModelSerializer):
    """Serializer for Vendor Profile."""

    user_email = serializers.EmailField(source='user.email', read_only=True)
    user_name = serializers.SerializerMethodField()

    class Meta:
        model = VendorProfile
        fields = [
            'user', 'user_email', 'user_name', 'business_name', 'address',
            'city', 'state', 'bio', 'cac_document', 'verification_status',
            'verified_at', 'rejection_reason', 'created_at', 'updated_at'
        ]
        read_only_fields = ['user', 'verification_status', 'verified_at', 'rejection_reason', 'created_at', 'updated_at']

    def get_user_name(self, obj):
        """Get the full name of the user."""
        return f"{obj.user.first_name} {obj.user.last_name}"

    def validate(self, attrs):
        """Validate that the user is a vendor."""
        user = self.context['request'].user
        if user.role != User.Role.VENDOR:
            raise serializers.ValidationError("Only users with vendor role can create a vendor profile.")
        return attrs

    def create(self, validated_data):
        """Create vendor profile for the authenticated user."""
        validated_data['user'] = self.context['request'].user
        return super().create(validated_data)


class VendorProfilePublicSerializer(serializers.ModelSerializer):
    """Public serializer for Vendor Profile (for display on listings)."""

    user_name = serializers.SerializerMethodField()

    class Meta:
        model = VendorProfile
        fields = ['business_name', 'user_name', 'city', 'state', 'bio']

    def get_user_name(self, obj):
        """Get the full name of the user."""
        return f"{obj.user.first_name} {obj.user.last_name}"
